import 'package:awesome_dio_interceptor/awesome_dio_interceptor.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/helper/cache_helper.dart';
import 'package:zawaj/features/chats_list/data/model/chats_model.dart';

class ChatRepository {
  final Dio dio;

  ChatRepository(this.dio);

  Future<List<Chat>> getChats() async {
    dio.interceptors.add(
      AwesomeDioInterceptor(
        logRequestTimeout: false,
        logRequestHeaders: false,
        logResponseHeaders: false,
        logger: debugPrint,
      ),
    );
    try {
      String? token = await CacheHelper.getData(key: Strings.token);

      final response = await dio.get(
        'http://51.195.41.3/api/HomeUser/GetChats',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
      final List<dynamic> jsonList = response.data;
      return jsonList.map((json) => Chat.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to load chats');
    }
  }
}
