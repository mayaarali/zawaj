class Chat {
  final int chatId;
  final String userId;
  final String lastMessage;
  final String userName;
  final List<String> userImages;

  Chat({
    required this.chatId,
    required this.userId,
    required this.lastMessage,
    required this.userName,
    required this.userImages,
  });

  factory Chat.fromJson(Map<String, dynamic> json) {
    return Chat(
      chatId: json['chatId'],
      userId: json['userId'],
      lastMessage: json['lastMessage'],
      userName: json['userName'],
      userImages: List<String>.from(json['userImages']),
    );
  }
}