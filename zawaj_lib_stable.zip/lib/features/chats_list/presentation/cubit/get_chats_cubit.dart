import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/chats_list/data/model/chats_model.dart';
import 'package:zawaj/features/chats_list/domain/reposiory/repository.dart';
import 'package:zawaj/features/chats_list/presentation/cubit/get_chats_statets';

class ChatsCubit extends Cubit<ChatsState> {
  final GetChats getChats;

  ChatsCubit(this.getChats) : super(ChatsInitial());

  Future<void> fetchChats() async {
    emit(ChatsLoading());
    final result = await getChats();
    result.fold(
      (error) => emit(ChatsError(error.toString())),
      (chats) => emit(ChatsLoaded(chats)),
    );
  }
}
