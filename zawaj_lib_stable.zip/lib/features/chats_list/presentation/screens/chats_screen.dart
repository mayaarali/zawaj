import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/custom_text_field.dart';
import 'package:zawaj/features/chat/presentation/screens/chat_screen.dart';
import 'package:zawaj/features/chats_list/data/model/chats_model.dart';
import 'package:zawaj/features/chats_list/data/repository/repository_impl.dart';
import 'package:zawaj/features/chats_list/domain/reposiory/repository.dart';
import 'package:zawaj/features/chats_list/presentation/cubit/get_chats_cubit.dart';
import 'package:zawaj/features/chats_list/presentation/cubit/get_chats_statets';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:cached_network_image/cached_network_image.dart';

import '../../../../core/constants/color_manager.dart';
import '../../../../core/router/routes.dart';

class ChatScreenList extends StatefulWidget {
  const ChatScreenList({super.key});

  @override
  _ChatScreenListState createState() => _ChatScreenListState();
}

class _ChatScreenListState extends State<ChatScreenList> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                    child: CustomTextField(
                  hintText: 'search',
                  height: 60,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                )),
                const SizedBox(
                  width: 30,
                ),
                InkWell(
                    onTap: () {
                      MagicRouter.goBack();
                    },
                    child: const Icon(
                      Icons.arrow_forward,
                      color: ColorManager.hintTextColor,
                    )),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            Expanded(
              child: ChatList(searchQuery: _searchQuery),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatList extends StatelessWidget {
  final String searchQuery;

  const ChatList({super.key, required this.searchQuery});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ChatsCubit, ChatsState>(
      builder: (context, state) {
        if (state is ChatsLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is ChatsLoaded) {
          final List<Chat> chats = state.chats.where((chat) {
            return (chat)
                .userName
                .toLowerCase()
                .contains(searchQuery.toLowerCase());
          }).toList();

          if (chats.isEmpty) {
            return const Center(child: Text('لا يوجد محادثات'));
          } else {
            return Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const CustomText(
                      text: 'مراسلات',
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Container(
                      height: 25,
                      width: 25,
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: ColorManager.secondaryPinkColor),
                      child: Padding(
                        padding: const EdgeInsets.all(2),
                        child: Center(
                            child: CustomText(
                          text: '${_getTotalChats(context)}',
                        )),
                      ),
                    )
                  ],
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: chats.length,
                    itemBuilder: (context, index) {
                      return ChatItem(
                        name: chats[index].userName,
                        lastMessage: chats[index].lastMessage,
                        imageUrl:
                            '${EndPoints.BASE_URL_image}${chats[index].userImages[0]}',
                        userId: chats[index].userId,
                      );
                    },
                  ),
                ),
              ],
            );
          }
        } else if (state is ChatsError) {
          return const Center(child: Text(' ! خطا حدث'));
        } else {
          return const Center(child: Text(' ! خطا حدث'));
        }
      },
    );
  }

  int _getTotalChats(BuildContext context) {
    final chatsCubit = context.read<ChatsCubit>();
    if (chatsCubit.state is ChatsLoaded) {
      return (chatsCubit.state as ChatsLoaded).chats.length;
    }
    return 0;
  }
}

class ChatItem extends StatelessWidget {
  final String name;
  final String lastMessage;
  final String imageUrl;
  final String userId;
  const ChatItem(
      {super.key,
      required this.name,
      required this.lastMessage,
      required this.imageUrl,
      required this.userId});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        MagicRouter.navigateTo(ChatScreen(
          receiverId: userId,
          receiverProdileImage: imageUrl,
        ));
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipOval(
              child: CachedNetworkImage(
                imageUrl: imageUrl,
                height: 100,
                width: 100,
                placeholder: (context, url) =>
                    const Center(child: CircularProgressIndicator()),
                errorWidget: (context, url, error) => const Icon(Icons.error),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomText(
                  text: name,
                  align: TextAlign.center,
                ),
                CustomText(
                  text: lastMessage,
                  align: TextAlign.center,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
