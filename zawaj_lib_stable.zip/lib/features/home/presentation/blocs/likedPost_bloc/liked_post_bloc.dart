import 'package:bloc/bloc.dart';
import 'package:zawaj/features/home/data/repository/home_repo.dart';
import '../home_bloc/home_bloc.dart';

class LikedPostBloc extends Bloc<HomeEvent, HomeState> {
  HomeRepositoryImp homeRepositoryImp;
  LikedPostBloc({required this.homeRepositoryImp}) : super(HomeInitial()) {
    on<LikePostEvent>((event, emit) async {
      emit(IsLikedPostLoading());
      var response =
          await homeRepositoryImp.isLikedPost(userId: event.userId.toString());
      response.fold((failure) {
        emit(IsLikedPostFailure(message: failure));
      }, (message) {
        emit(IsLikedPostSuccess(message: message));
      });
    });

    on<DisLikePostEvent>((event, emit) async {
      emit(IsDisLikedPostLoading());
      var response = await homeRepositoryImp.isDisLikedPost(
          userId: event.userId.toString());
      response.fold((failure) {
        emit(IsLikedPostFailure(message: failure));
      }, (message) {
        emit(IsLikedPostSuccess(message: message));
      });
    });

    on<RemoveUserEvent>((event, emit) async {
      emit(RemoveUserLoading());
      var response =
          await homeRepositoryImp.removeUser(userId: event.userId.toString());
      response.fold((failure) {
        emit(RemoveUserFailure(message: failure));
      }, (message) {
        emit(RemoveUserSuccess(message: message));
      });
    });
  }
}
