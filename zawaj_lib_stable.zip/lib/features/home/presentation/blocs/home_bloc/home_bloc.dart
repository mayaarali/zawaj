import 'package:bloc/bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:zawaj/features/home/data/repository/home_repo.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeRepositoryImp homeRepositoryImp;
  static HomeBloc get(context) => BlocProvider.of(context);

  HomeBloc({required this.homeRepositoryImp}) : super(HomeInitial()) {
    // on<HomeEvent>((event, emit) async {
    //   emit(HomeLoading());
    //   var response = await homeRepositoryImp.getPartnerData();
    //   print("hoooome blooccc");
    //   response.fold((failure) {
    //     emit(HomeFailure(message: failure));
    //   }, (homeList) {
    //     emit(HomeSuccess(homeList));
    //     print("hooome successs");
    //   });
    // });
/*
    on<LikePostEvent>((event, emit) async {
      emit(IsLikedPostLoading());
      var response = await homeRepositoryImp.isLikedPost(postId: event.postId);

      response.fold((failure) {
        emit(IsLikedPostFailure(message: failure));
      }, (message) {
        emit(IsLikedPostSuccess(message: message));
      });
    });
    */
  }
  HomeModel? homeModel;
  getHomeData() async {
    emit(HomeLoading());
    var response = await homeRepositoryImp.getPartnerData();
    print(response);
    print("hoooome blooccc");
    response.fold((failure) {
      emit(HomeFailure(message: failure));
    }, (homeList) {
      emit(HomeSuccess(homeList));
      print("hooome successs");
    });
  }
}
