import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/core/widgets/loading_popup.dart';
import 'package:zawaj/features/chat/presentation/screens/chat_screen.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:zawaj/features/home/presentation/pages/partner_details_screen.dart';
import 'package:zawaj/features/profile/presentation/bloc/profile_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';

import '../../../profile/presentation/pages/popup_pages/send_report/presentation/screen/send_report.dart';
import '../blocs/home_bloc/home_bloc.dart';
import '../blocs/likedPost_bloc/liked_post_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    HomeBloc.get(context).getHomeData();
    ProfileBloc.get(context).profileData;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final homeBloc = BlocProvider.of<HomeBloc>(context);
    return CustomScaffold(
        isFullScreen: true,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomAppBar(
              isSettingIcon: true,
              isBack: false,
              isMenuIcon: true,
              isHeartTitle: true,
              leading: GestureDetector(
                onTap: () {
                  MagicRouter.navigateTo(SetPartnerData(isUpdated: true));
                },
                child: SvgPicture.asset(
                  ImageManager.settingIcon,
                  fit: BoxFit.scaleDown,
                ),
              ),
            ),
            BlocConsumer<HomeBloc, HomeState>(
                listener: (context, state) {},
                builder: (context, state) => state is HomeLoading
                    ? const LoadingPopUp()
                    : state is HomeSuccess
                        ? BlocConsumer<LikedPostBloc, HomeState>(
                            listener: (context, state) {
                              if (state is IsLikedPostFailure) {
                                context.getSnackBar(
                                    snackText: state.message, isError: true);
                              }
                              if (state is IsLikedPostSuccess) {
                                context.getSnackBar(
                                  snackText: state.message,
                                );
                                homeBloc.getHomeData();
                              }

                              if (state is RemoveUserFailure) {
                                context.getSnackBar(
                                    snackText: state.message, isError: true);
                              }

                              if (state is RemoveUserSuccess) {
                                context.getSnackBar(
                                  snackText: state.message,
                                );
                                homeBloc.getHomeData();
                              }
                            },
                            builder: (context, s) => Expanded(
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    ListView.builder(
                                      shrinkWrap: true,
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemCount: state.homeList.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return PartnerWidget(
                                            homeModel: state.homeList[index]);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        : const SizedBox())
          ],
        ));
  }
}

class PartnerWidget extends StatelessWidget {
  PartnerWidget({Key? key, required this.homeModel}) : super(key: key);
  final HomeModel homeModel;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          alignment: AlignmentDirectional.bottomEnd,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: homeModel.images == null || homeModel.images!.isEmpty
                  ? const Icon(Icons.add)
                  : GestureDetector(
                      onTap: () {
                        MagicRouter.navigateTo(
                            PartnerDetailsScreen(homeModel: homeModel));
                      },
                      child: Image.network(
                          EndPoints.BASE_URL_image + homeModel.images![0],
                          width: context.width,
                          height: context.height * 0.5,
                          fit: BoxFit.fill,
                          errorBuilder: (context, error, stackTrace) {
                        return const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(child: Icon(Icons.error)),
                          ],
                        );
                      }, frameBuilder:
                              (context, child, frame, wasSynchronouslyLoaded) {
                        return child;
                      }, loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) {
                          return child;
                        } else {
                          return const Center(
                            child: LoadingCircle(),
                          );
                        }
                      }),
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                children: [
                  Card(
                    color: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)),
                    child: GestureDetector(
                      onTap: () {
                        MagicRouter.navigateTo(SendReport(
                          userId: homeModel.userId.toString(),
                        )
                            // BlocProvider.of<LikedPostBloc>(context).add(
                            //   RemoveUserEvent(userId: homeModel.id.toString()),
                            );
                      },
                      child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.5)),
                          child: SvgPicture.asset(
                            ImageManager.closeIcon,
                            width: 14,
                            height: 14,
                            fit: BoxFit.scaleDown,
                          )),
                    ),
                  ),
                  Card(
                    color: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)),
                    child: GestureDetector(
                      onTap: () {
                        //     BlocProvider.of<ChatBloc>(context).add(SendMessageEvent(receiverId: homeModel.userId!));
                        MagicRouter.navigateTo(ChatScreen(
                          receiverProdileImage:
                              EndPoints.BASE_URL_image + homeModel.images![0],
                          receiverId: homeModel.userId!,
                        ));
                      },
                      child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              //  image: DecorationImage(
                              // image:
                              //      AssetImage(ImageManager.circularBackground)),
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.5)),
                          child: SvgPicture.asset(
                            ImageManager.chatIcon,
                            width: 14,
                            height: 14,
                            fit: BoxFit.scaleDown,
                          )),
                    ),
                  ),
                  Card(
                    color: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)),
                    child: GestureDetector(
                      onTap: () {
                        if (homeModel.isLiked == false) {
                          BlocProvider.of<LikedPostBloc>(context).add(
                            LikePostEvent(userId: homeModel.id.toString()),
                          );
                        }

                        if (homeModel.isLiked == true) {
                          BlocProvider.of<LikedPostBloc>(context).add(
                            DisLikePostEvent(userId: homeModel.id.toString()),
                          );
                        }
                      },
                      child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              //  image: DecorationImage(
                              // image:
                              //AssetImage(ImageManager.circularBackground)),
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.5)),
                          child: homeModel.isLiked == true
                              ? const Icon(
                                  Icons.favorite,
                                  color: ColorManager.primaryColor,
                                )
                              : SvgPicture.asset(
                                  ImageManager.favIcon,
                                  width: 14,
                                  height: 14,
                                  fit: BoxFit.scaleDown,
                                )),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomText(
              text: homeModel.name,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              width: 15,
            ),
            CustomText(
              text: homeModel.city,
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
                child: CustomText(
              text: homeModel.about,
              fontSize: Dimensions.normalFont,
              align: TextAlign.start,
            )),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }
}
