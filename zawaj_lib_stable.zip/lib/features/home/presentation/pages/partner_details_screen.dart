import 'package:another_carousel_pro/another_carousel_pro.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_report/presentation/screen/send_report.dart';

class PartnerDetailsScreen extends StatelessWidget {
  const PartnerDetailsScreen({super.key, required this.homeModel});
  final HomeModel homeModel;
  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isFullScreen: true,
      child: SingleChildScrollView(
        child: Column(
          children: [
            CustomAppBar(
              isHeartTitle: true,
              leading: GestureDetector(
                onTap: () {
                  MagicRouter.navigateTo(SendReport(
                    userId: homeModel.id.toString(),
                  ));
                },
                child: const Padding(
                    padding: EdgeInsets.all(15),
                    child: Icon(
                        color: ColorManager.primaryColor,
                        size: 30,
                        Icons.more_horiz_outlined)),
              ),
            ),
            InfoLabel(homeModel: homeModel),
            //  ParametersList(parameters: homeModel.parameters,
            // )
          ],
        ),
      ),
    );
  }
}

class InfoLabel extends StatelessWidget {
  const InfoLabel({super.key, required this.homeModel});

  final HomeModel homeModel;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: CarouselSlider(
            items: homeModel.images!.map((image) {
              return ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.network(
                  EndPoints.BASE_URL_image + image,
                  width: context.width,
                  height: context.height * 0.3,
                  fit: BoxFit.fill,
                  errorBuilder: (context, error, stackTrace) {
                    return const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(child: Icon(Icons.error)),
                      ],
                    );
                  },
                  frameBuilder:
                      (context, child, frame, wasSynchronouslyLoaded) {
                    return child;
                  },
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) {
                      return child;
                    } else {
                      return const Center(
                        child: LoadingCircle(),
                      );
                    }
                  },
                ),
              );
            }).toList(),
            options: CarouselOptions(autoPlay: true, enlargeCenterPage: true),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomText(
              text: homeModel.name,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              width: 15,
            ),
            CustomText(
              text: homeModel.city,
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
                child: CustomText(
              text: homeModel.about,
              fontSize: Dimensions.normalFont,
              align: TextAlign.start,
            )),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Wrap(
          spacing: 25,
          runSpacing: 10,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "العمر"),
                CustomText(
                  text: homeModel.age.toString(),
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                )
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "الحالة الاجتماعية"),
                CustomText(
                  text: homeModel.maritalStatus,
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                )
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "المنطقة"),
                CustomText(
                  text: homeModel.area,
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "هل تدخن"),
                CustomText(
                  text: homeModel.isSmoking! ? Strings.yes : Strings.no,
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "الوزن"),
                CustomText(
                  text: homeModel.weight.toString(),
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CustomText(
                    color: ColorManager.hintTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                    text: "الطول"),
                CustomText(
                  text: homeModel.height.toString(),
                  color: ColorManager.primaryTextColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
            ParametersList(parameters: homeModel.parameters)
          ],
        ),
      ],
    );
  }
}

class ParametersList extends StatelessWidget {
  const ParametersList({super.key, required this.parameters});

  final List<Parameter>? parameters;

  @override
  Widget build(BuildContext context) {
    if (parameters == null || parameters!.isEmpty) {
      return Container();
    }
    return Wrap(
      spacing: 25,
      runSpacing: 10,
      children: parameters!.map((parameter) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              color: ColorManager.hintTextColor,
              fontSize: 18,
              fontWeight: FontWeight.w400,
              text: parameter.parameterName ?? '',
            ),
            CustomText(
              text: parameter.valueName ?? '',
              color: ColorManager.primaryTextColor,
              fontSize: 18,
              fontWeight: FontWeight.w400,
            ),
          ],
        );
      }).toList(),
    );
    /*
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 25,
        mainAxisSpacing: 10,
      ),
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: parameters!.length,
      itemBuilder: (context, index) {
        final parameter = parameters![index];
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                color: ColorManager.hintTextColor,
                fontSize: 18,
                fontWeight: FontWeight.w400,
                text: parameter.parameterName ?? '',
              ),
              CustomText(
                text: parameter.valueName ?? '',
                color: ColorManager.primaryTextColor,
                fontSize: 18,
                fontWeight: FontWeight.w400,
              ),
            ],
          ),
        );
      },
      */
    /*
      scrollDirection: Axis.horizontal,
      shrinkWrap: true,
      //  physics: NeverScrollableScrollPhysics(),
      itemCount: parameters!.length,
      itemBuilder: (context, index) {
        final parameter = parameters![index];
        return Row(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                      color: ColorManager.hintTextColor,
                      fontSize: 18,
                      fontWeight: FontWeight.w400,
                      text: parameter.parameterName ?? ''),
                  CustomText(
                    text: parameter.valueName ?? '',
                    color: ColorManager.primaryTextColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w400,
                  ),
                ],
              ),
            ),
          ],
        );
      },*/
  }
}
