part of 'who_like_me_bloc.dart';

abstract class WhoLikeMeState {}

final class WhoLikeMeInitial extends WhoLikeMeState {}

final class WhoLikeMeLoading extends WhoLikeMeState {}

final class WhoLikeMeSuccess extends WhoLikeMeState {
  List<HomeModel> homeModel;
  WhoLikeMeSuccess(this.homeModel);
}

final class WhoLikeMeFailure extends WhoLikeMeState {
  String mesaage;
  WhoLikeMeFailure({required this.mesaage});
}
