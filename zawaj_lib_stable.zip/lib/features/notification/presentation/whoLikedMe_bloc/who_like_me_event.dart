part of 'who_like_me_bloc.dart';

abstract class WhoLikeMeEvent {}

class WhoLikedEvent extends WhoLikeMeEvent {}
