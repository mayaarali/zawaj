import 'package:blur/blur.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:zawaj/features/notification/presentation/screens/empty_notification.dart';
import 'package:zawaj/features/notification/presentation/screens/likes_notification_page.dart';
import 'package:zawaj/features/notification/presentation/whoLikedMe_bloc/who_like_me_bloc.dart';
import 'package:zawaj/features/payment/presentation/pages/choose_bundle_screen.dart';

class BlurNotification extends StatefulWidget {
  const BlurNotification({super.key});

  @override
  State<BlurNotification> createState() => _BlurNotificationState();
}

class _BlurNotificationState extends State<BlurNotification> {
  @override
  void initState() {
    super.initState();
    final whoLikeMeBloc = BlocProvider.of<WhoLikeMeBloc>(context);
    whoLikeMeBloc.add(WhoLikedEvent());
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isFullScreen: true,
      child: Container(
        // color: Colors.red,
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const CustomAppBar(
              title: Strings.notification,
              isBack: false,
              isMenuIcon: true,
            ),
            const SizedBox(
              height: 20,
            ),
            BlocConsumer<WhoLikeMeBloc, WhoLikeMeState>(
              listener: (context, state) {},
              builder: (context, state) => state is WhoLikeMeLoading
                  ? const LoadingCircle()
                  : state is WhoLikeMeSuccess
                      ? state.homeModel.isEmpty
                          ? const EmptyNotification()
                          : Center(
                              child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20)),
                                child: GridView.builder(
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisSpacing: 20,
                                          crossAxisCount: 2,
                                          mainAxisSpacing: 50),
                                  shrinkWrap: true,
                                  itemCount: 1,
                                  physics: const BouncingScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return WhoLikedBlured(
                                            homeModel: state.homeModel[index])
                                        .blurred(
                                      colorOpacity: 0.1,
                                    );
                                  },
                                ),
                              ),
                            )
                      : const SizedBox(),
            ),
            const SizedBox(
              height: 70,
            ),
            const CustomText(
              text: Strings.wholikesyou,
              fontSize: 20,
            ),
            const SizedBox(
              height: 30,
            ),
            CustomButton(
              onTap: () {
                MagicRouter.navigateTo(
                    //    const LikeNotificationPage()
                    ChooseBundle());
              },
              text: Strings.gopaymentbutton,
            ),
            const SizedBox(height: 100),
          ]),
        ),
      ),
    );
  }
}

class WhoLikedBlured extends StatelessWidget {
  const WhoLikedBlured({super.key, required this.homeModel});
  final HomeModel homeModel;
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 12,
      runSpacing: 20,
      children: [
        Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.network(
                  EndPoints.BASE_URL_image + homeModel.images![0],
                  width: context.width * 0.40,
                  height: context.height * 0.2,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                return const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(child: Icon(Icons.error)),
                  ],
                );
              }, frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                return child;
              }, loadingBuilder: (context, child, loadingProgress) {
                if (loadingProgress == null) {
                  return child;
                } else {
                  return const Center(
                    child: LoadingCircle(),
                  );
                }
              }),
            ),
          ],
        ),
      ],
    );
  }
}
