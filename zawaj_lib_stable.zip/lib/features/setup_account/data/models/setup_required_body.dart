import 'package:zawaj/features/setup_account/data/models/params_model.dart';

class SetupRequiredBody {
  int? searchGender;
  double? height;
  double? weight;
  bool? isSmoking;
  int? maxAge;
  int? minAge;
  List<ValueBody>? selectionModel;
  SetupRequiredBody({
    required this.searchGender,
    required this.maxAge,
    required this.minAge,
    required this.selectionModel,
    required this.height,
    required this.weight,
    required this.isSmoking,
  });

  Map<String, dynamic> toJson() => {
        "SearchGender": searchGender,
        "MinAge": minAge,
        "MaxAge": maxAge,
        "Height": height,
        "Weight": weight,
        "IsSmoking": isSmoking,
        "selectionModel": selectionModel == null
            ? []
            : List<dynamic>.from(selectionModel!.map((x) => x.toJson())),
      };
}

// class ValueListBody {
//   int? parameterId;
//   int? valueId;
//   String? valueName;

//   ValueListBody({
//     this.parameterId,
//     this.valueId,
//     this.valueName,
//   });


//   Map<String, dynamic> toJson() => {
//     "parameterId": parameterId,
//     "valueId": valueId,
//     "value": valueName,
//   };
// }
