import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/setup_account/data/models/params_model.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/event.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/params_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_0.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_1.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_2&4.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_3.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/build_dialog.dart';
import '../../../../core/widgets/custom_appbar.dart';
import '../bloc/setup_bloc.dart';
import '../bloc/states.dart';
import '../widgets/main_params.dart';

class SetPersonalData extends StatelessWidget {
  const SetPersonalData({super.key});

  @override
  Widget build(BuildContext context) {
    SetUpBloc bloc = SetUpBloc.get(context);

    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates state) {
        if (state is SuccessSetUp) {
          buildDialog(
              isDissmiss: false,
              onTapEnter: () {
                MagicRouter.navigateAndReplacement(SetPartnerData(
                  isUpdated: false,
                ));
              },
              buttonTitle: Strings.select_partner,
              title: Strings.congrats,
              desc: Strings.complete_setup,
              context: context);
        }
        if (state is FailedSetUp) {
          context.getSnackBar(snackText: state.message, isError: true);
        }
      },
      builder: (BuildContext context, SetUpStates state) => CustomScaffold(
          isFullScreen: true,
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.all(Dimensions.defaultPadding),
            child: state is LoadingSetUp
                ? SizedBox(
                    height: Dimensions(context: context).buttonHeight,
                    child: const LoadingCircle())
                : CustomButton(
                    onTap: () async {
                      await SetUpBloc.get(context).changeMapValue(
                          key: "Height",
                          value: double.tryParse(
                              SetUpBloc.get(context).heightController.text));
                      await SetUpBloc.get(context).changeMapValue(
                          key: "Weight",
                          value: double.tryParse(
                              SetUpBloc.get(context).weightController.text));

                      List<ValueBody?> list = [];
                      for (int i = 0;
                          i < SetUpBloc.get(context).dropValueBodyList!.length;
                          i++) {
                        if (SetUpBloc.get(context).dropValueBodyList![i] !=
                            null) {
                          list.add(
                              SetUpBloc.get(context).dropValueBodyList![i]);
                        }
                      }
                      for (var element
                          in SetUpBloc.get(context).multiSelectList!) {
                        list.add(element);
                      }

                      SetUpBloc.get(context).setUpMap.addEntries({
                            "selectionModel":
                                List<dynamic>.from(list.map((x) => x!.toJson()))
                          }.entries);

                      debugPrint(SetUpBloc.get(context).setUpMap.toString());
                      if (SetUpBloc.get(context).setUpMap["Height"] == null) {
                        context.getSnackBar(
                            snackText: 'You must add Height', isError: true);
                      } else if (SetUpBloc.get(context).setUpMap["Weight"] ==
                          null) {
                        context.getSnackBar(
                            snackText: 'You must add Weight', isError: true);
                      } else {
                        SetUpBloc.get(context).add(PostSetUpEvent());
                      }
                    },
                    text: Strings.save,
                  ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const CustomAppBar(
                title: Strings.my_personal_data,
                isBack: true,
              ),
              //  AgeRangeSelector(),
              const SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView(
                  children: [
                    MainParam(
                      heightController: bloc.heightController,
                      weightController: bloc.weightController,
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const ParamsBody(),
                  ],
                ),
              ),
            ],
          )),
    );
  }
}

class ParamsBody extends StatelessWidget {
  const ParamsBody({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates s) {},
      builder: (BuildContext context, SetUpStates s) => BlocConsumer<ParamsBloc,
              SetUpStates>(
          listener: (BuildContext context, SetUpStates state) {
            if (state is GetParamsSuccess) {
              SetUpBloc.get(context).fillSetupCollectList(state.paramsList);
              // SetUpBloc.get(context).dropValueBodyList =
              //     List.filled(state.paramsList.length, null);
              // SetUpBloc.get(context).dropValueList =
              //     List.filled(state.paramsList.length, null);
              // SetUpBloc.get(context).isChecked =
              //     List.filled(state.paramsList.length,null);
              print(SetUpBloc.get(context).isChecked.length);
            }
          },
          builder: (BuildContext context, SetUpStates state) => state
                  is GetParamsLoading
              ? const LinearProgressIndicator(
                  color: ColorManager.primaryColor,
                )
              : state is GetParamsSuccess
                  ? Padding(
                      padding: const EdgeInsetsDirectional.only(start: 10),
                      child: Wrap(
                        direction: Axis.horizontal,
                        children: [
                          for (int i = 0; i < state.paramsList.length; i++)
                            Padding(
                              padding: const EdgeInsetsDirectional.only(
                                  end: 10, bottom: 15),
                              child: Container(
                                width:
                                    // state.paramsList[i].type == 0
                                    //     ? (context.width * 0.5) - 45
                                    //     :
                                    (context.width) - 65,
                                // height: 60,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                        Dimensions.buttonRadius),
                                    border: Border.all(
                                        color: ColorManager.primaryColor)),
                                child: Center(
                                    child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 20),
                                        child: state.paramsList[i].type == 0
                                            ? SelectType(
                                                i: i,
                                                paramsList: state.paramsList,
                                              )
                                            : state.paramsList[i].type == 2
                                                ? TextNumberType(
                                                    paramsList:
                                                        state.paramsList,
                                                    isNumber: false,
                                                    i: i,
                                                  )
                                                : state.paramsList[i].type == 4
                                                    ? TextNumberType(
                                                        paramsList:
                                                            state.paramsList,
                                                        isNumber: true,
                                                        i: i,
                                                      )
                                                    : state.paramsList[i]
                                                                .type ==
                                                            3
                                                        ? DateType(
                                                            paramsList: state
                                                                .paramsList,
                                                            i: i,
                                                          )
                                                        : MultiSelectType(
                                                            i: i,
                                                            paramsModel: state
                                                                    .paramsList[
                                                                i]))),
                              ),
                            )
                        ],
                      ),
                    )
                  : const SizedBox()),
    );
  }
}
