import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/setup_bloc.dart';

import '../../../../../core/constants/color_manager.dart';
import '../../../../../core/widgets/custom_text.dart';
import '../../../data/models/params_model.dart';

class TextNumberType extends StatelessWidget {
  const TextNumberType({
    super.key,
    Key? keyy,
    required this.i,
    required this.paramsList,
    required this.isNumber,
  });

  final int i;
  final List<ParamsModel> paramsList;

  final bool isNumber;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ExpandablePanel(
        theme: const ExpandableThemeData(
          iconColor: ColorManager.primaryColor,
        ),
        header: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: CustomText(
                text: paramsList[i].title,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        expanded: Column(
          children: [
            TextField(
              onChanged: (v) {
                SetUpBloc.get(context).changeDropList(
                    i, Value(id: null, value: v), paramsList[i].id);
              },
              decoration: InputDecoration(
                  hintText: SetUpBloc.get(context).dropValueList![i] == null
                      ? ''
                      : SetUpBloc.get(context).dropValueList![i]!.value ?? ''),
              // controller:controller ,
              keyboardType:
                  isNumber ? TextInputType.number : TextInputType.text,
            ),
            const SizedBox(
              height: 20,
            ),
          ],
        ),
        collapsed: const SizedBox(),
      ),
    );
  }
}
