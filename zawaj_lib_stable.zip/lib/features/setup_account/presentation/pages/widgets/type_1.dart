import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/setup_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/states.dart';

import '../../../../../core/constants/color_manager.dart';
import '../../../../../core/widgets/custom_text.dart';
import '../../../data/models/params_model.dart';

class MultiSelectType extends StatefulWidget {
  const MultiSelectType(
      {super.key, required this.paramsModel, required this.i});
  final ParamsModel paramsModel;
  final int i;
  @override
  State<MultiSelectType> createState() => _MultiSelectTypeState();
}

class _MultiSelectTypeState extends State<MultiSelectType> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: ExpandablePanel(
        theme: const ExpandableThemeData(
          iconColor: ColorManager.primaryColor,
        ),
        header: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              CustomText(
                text: widget.paramsModel.title.toString(),
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ],
          ),
        ),
        expanded: BlocConsumer<SetUpBloc, SetUpStates>(
          listener: (context, state) {},
          builder: (context, state) {
            return ListView.builder(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: widget.paramsModel.values!.length,
              itemBuilder: (context, index) => Directionality(
                textDirection: TextDirection.rtl,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Checkbox(
                      value: SetUpBloc.get(context)
                              .isChecked[widget.i]![index]!
                              .value ??
                          false,
                      onChanged: (value) {
                        setState(() {
                          if (value == true) {
                            if (!SetUpBloc.get(context)
                                .multiSelectList!
                                .contains(ValueBody(
                                  paramId: widget.paramsModel.id,
                                  value:
                                      widget.paramsModel.values![index].value,
                                  valueId: widget.paramsModel.values![index].id,
                                ))) {
                              print('add multi select');
                              SetUpBloc.get(context).multiSelectList!.add(
                                    ValueBody(
                                      paramId: widget.paramsModel.id,
                                      value: widget
                                          .paramsModel.values![index].value,
                                      valueId:
                                          widget.paramsModel.values![index].id,
                                    ),
                                  );
                            }
                          } else {
                            SetUpBloc.get(context)
                                .multiSelectList!
                                .removeWhere((element) {
                              return element?.valueId ==
                                  widget.paramsModel.values![index].id;
                            });
                          }
                          SetUpBloc.get(context)
                              .isChecked[widget.i]![index]!
                              .value = value;
                        });
                      },
                    ),
                    CustomText(
                      text: widget.paramsModel.values![index].value ?? "",
                      color: Colors.black,
                    )
                  ],
                ),
              ),
            );
          },
        ),
        collapsed: const SizedBox(),
      ),
    );
  }
}
