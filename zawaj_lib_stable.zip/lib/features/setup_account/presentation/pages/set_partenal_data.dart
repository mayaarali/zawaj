import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/profile/presentation/bloc/profile_bloc.dart';
import 'package:zawaj/features/profile/presentation/bloc/states.dart';
import 'package:zawaj/features/setup_account/data/models/params_model.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/event.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/params_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_0.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_1.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_2&4.dart';
import 'package:zawaj/features/setup_account/presentation/pages/widgets/type_3.dart';
import 'package:zawaj/injection_controller.dart' as di;

import '../../../../core/constants/image_manager.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/custom_appbar.dart';
import '../../data/models/setup_required_body.dart';
import '../bloc/setup_bloc.dart';
import '../bloc/states.dart';
import '../widgets/age_selector.dart';
import '../widgets/main_params.dart';

class SetPartnerData extends StatefulWidget {
  SetPartnerData({
    super.key,
    required this.isUpdated,
  });
  final bool isUpdated;
  @override
  State<SetPartnerData> createState() => _SetPartnerDataState();
}

class _SetPartnerDataState extends State<SetPartnerData> {
  @override
  void initState() {
    super.initState();
    if (widget.isUpdated) {
      ProfileBloc.get(context).getMyPartner();
      print('iaminit');
    }
  }

  void initializeSetUpRequiredBody() async {
    await di.sl<ParamsBloc>().getParams();
    print('initializeSetUpRequiredBody');
    log(ProfileBloc.get(context).partnerData.toString());
    if (widget.isUpdated && ProfileBloc.get(context).partnerData != null) {
      print('isUpdated && ProfileBloc.get(context).partnerData != null');
      SetUpBloc bloc = SetUpBloc.get(context);
      SetupRequiredBody setupRequiredBody = SetupRequiredBody(
        searchGender:
            ProfileBloc.get(context).partnerData!.gender!.toLowerCase() ==
                    "male"
                ? 0
                : 1,
        maxAge: ProfileBloc.get(context).partnerData!.maxAge,
        minAge: ProfileBloc.get(context).partnerData!.minAge,
        selectionModel: [],
        height: ProfileBloc.get(context).partnerData!.height,
        weight: ProfileBloc.get(context).partnerData!.weight,
        isSmoking: ProfileBloc.get(context).partnerData!.isSmoking,
      );
      SetUpBloc.get(context).heightRequiredController.text =
          setupRequiredBody.height.toString();
      SetUpBloc.get(context).weightRequiredController.text =
          setupRequiredBody.weight.toString();
      bloc.setUpMap['IsSmoking'] = setupRequiredBody.isSmoking;
      bloc.setUpMap['SearchGender'] = setupRequiredBody.searchGender;
      bloc.selectedAgeRange = RangeValues(setupRequiredBody.minAge!.toDouble(),
          setupRequiredBody.maxAge!.toDouble());

      // SetUpBloc.get(context).fillSetupCollectList(ProfileBloc.get(context).partnerData!.parameters!,isUpdate: true);

      // SetUpBloc.get(context).dropValueBodyList=[];
      //SetUpBloc.get(context).textParams
      SetUpBloc.get(context).multiSelectList = [];
      for (int i = 0;
          i < ProfileBloc.get(context).partnerData!.parameters!.length;
          i++) {
        print('iam in first for loop[$i]');
        print(
            ProfileBloc.get(context).partnerData!.parameters![i].parameterType);
        print(ProfileBloc.get(context)
                .partnerData!
                .parameters![i]
                .parameterType ==
            0);

        print(ProfileBloc.get(context).partnerData!.parameters);

        if (ProfileBloc.get(context)
                .partnerData!
                .parameters![i]
                .parameterType ==
            1) {
          for (int i1 = 0; i1 < SetUpBloc.get(context).isChecked.length; i1++) {
            if (SetUpBloc.get(context).isChecked[i1] != null) {
              print("checked not null");
              print(SetUpBloc.get(context).isChecked[i1]!);

              for (int i2 = 0;
                  i2 < SetUpBloc.get(context).isChecked[i1]!.length;
                  i2++) {
                print(
                    'valueId===>${ProfileBloc.get(context).partnerData!.parameters![i].valueId}');
                print(
                    'isCheckedIndex===>${SetUpBloc.get(context).isChecked[i1]![i2]!.index}');

                if (SetUpBloc.get(context)
                        .isChecked[i1]![i2]!
                        .index
                        .toString() ==
                    ProfileBloc.get(context)
                        .partnerData!
                        .parameters![i]
                        .valueId
                        .toString()) {
                  print('iam innnn');
                  SetUpBloc.get(context).isChecked[i1]![i2]!.value = true;
                  SetUpBloc.get(context).multiSelectList!.add(
                        ValueBody(
                          paramId: ProfileBloc.get(context)
                              .partnerData!
                              .parameters![i]
                              .parameterId,
                          value: ProfileBloc.get(context)
                              .partnerData!
                              .parameters![i]
                              .valueName,
                          valueId: ProfileBloc.get(context)
                              .partnerData!
                              .parameters![i]
                              .valueId,
                        ),
                      );

                  setState(() {});
                }
              }
            }
          }

          print(
              'len multiselect init =${SetUpBloc.get(context).multiSelectList!.length}');
        } else {
          for (int paramIndex = 0;
              paramIndex < ParamsBloc.get(context).paramsList.length;
              paramIndex++) {
            if (ParamsBloc.get(context).paramsList[paramIndex].id ==
                ProfileBloc.get(context)
                    .partnerData!
                    .parameters![i]
                    .parameterId) {
              SetUpBloc.get(context).changeDropList(
                  paramIndex,
                  Value(
                      value: ProfileBloc.get(context)
                          .partnerData!
                          .parameters![i]
                          .valueName,
                      id: ProfileBloc.get(context)
                          .partnerData!
                          .parameters![i]
                          .valueId),
                  ProfileBloc.get(context)
                      .partnerData!
                      .parameters![i]
                      .parameterId);
              //  break;
            }
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    SetUpBloc bloc = SetUpBloc.get(context);
    return BlocConsumer<ParamsBloc, SetUpStates>(
      listener: (context, state) {
        print(ProfileBloc.get(context).partnerData);
        if (state is GetParamsSuccess) {
          SetUpBloc.get(context).dropValueList =
              List.filled(state.paramsList.length, null);
          SetUpBloc.get(context).dropValueBodyList =
              List.filled(state.paramsList.length, null);
        }
      },
      builder: (context, state) => BlocConsumer<ProfileBloc, ProfileStates>(
        listener: (context, state) {
          print(ProfileBloc.get(context).partnerData);
          if (state is SuccessPartner) {
            initializeSetUpRequiredBody();
          }
        },
        builder: (context, state) {
          print(ProfileBloc.get(context).partnerData);

          return BlocConsumer<SetUpBloc, SetUpStates>(
            listener: (BuildContext context, SetUpStates state) {
              if (state is SuccessRequiredSetUp) {
                MagicRouter.navigateAndReplacement(const DashBoardScreen(
                  initialIndex: 2,
                ));
              }
              if (state is FailedRequiredSetUp) {
                context.getSnackBar(snackText: state.message, isError: true);
              }
            },
            builder: (BuildContext context, SetUpStates state) =>
                CustomScaffold(
                    isFullScreen: true,
                    bottomNavigationBar: Padding(
                      padding: const EdgeInsets.all(Dimensions.defaultPadding),
                      child: state is LoadingRequiredSetUp
                          ? SizedBox(
                              height: Dimensions(context: context).buttonHeight,
                              child: const LoadingCircle())
                          : CustomButton(
                              onTap: () async {
                                List<ValueBody> list = [];

                                print(
                                    'len of value body List${SetUpBloc.get(context).multiSelectList!.length}');
                                for (int i = 0;
                                    i <
                                        SetUpBloc.get(context)
                                            .dropValueBodyList!
                                            .length;
                                    i++) {
                                  if (SetUpBloc.get(context)
                                          .dropValueBodyList![i] !=
                                      null) {
                                    print(
                                        'len of value body List111${SetUpBloc.get(context).dropValueBodyList!.length}');
                                    list.add(SetUpBloc.get(context)
                                        .dropValueBodyList![i]!);
                                  }
                                }
                                // for (var element
                                //     in SetUpBloc.get(context).multiSelectList!) {
                                //   list.add(element!);
                                // }
                                for (var element in SetUpBloc.get(context)
                                    .multiSelectList!) {
                                  print(
                                      'len of value body List222${SetUpBloc.get(context).multiSelectList!.length}');
                                  list.add(ValueBody(
                                    paramId: element?.paramId,
                                    valueId: element?.valueId,
                                    value: element?.value,
                                  ));
                                }

                                SetUpBloc.get(context).setUpMap.addEntries({
                                      "selectionModel": jsonEncode(list)
                                    }.entries);
                                SetUpBloc.get(context).setUpMap.addEntries({
                                      "selectionModel": jsonEncode(
                                          SetUpBloc.get(context)
                                              .multiSelectList)
                                    }.entries);

                                if (SetUpBloc.get(context)
                                        .heightRequiredController
                                        .text ==
                                    '') {
                                  context.getSnackBar(
                                      snackText: 'You must add Height',
                                      isError: true);
                                } else if (SetUpBloc.get(context)
                                        .weightRequiredController
                                        .text ==
                                    '') {
                                  context.getSnackBar(
                                      snackText: 'You must add Weight',
                                      isError: true);
                                } else if (widget.isUpdated) {
                                  SetupRequiredBody setupRequiredBody =
                                      SetupRequiredBody(
                                          searchGender:
                                              bloc.setUpMap['SearchGender'],
                                          maxAge: SetUpBloc.get(context)
                                              .selectedAgeRange
                                              .end
                                              .toInt(),
                                          minAge: SetUpBloc.get(context)
                                              .selectedAgeRange
                                              .start
                                              .toInt(),
                                          selectionModel: list,
                                          height: double.tryParse(
                                              SetUpBloc.get(context)
                                                  .weightRequiredController
                                                  .text),
                                          weight: double.tryParse(
                                              SetUpBloc.get(context)
                                                  .heightRequiredController
                                                  .text),
                                          isSmoking:
                                              bloc.setUpMap['IsSmoking']);
                                  debugPrint(
                                      'read body${setupRequiredBody.toJson()}');
                                  SetUpBloc.get(context).add(UpdatePertnerEvent(
                                      setupRequiredBody: setupRequiredBody));
                                } else {
                                  SetupRequiredBody setupRequiredBody =
                                      SetupRequiredBody(
                                          searchGender:
                                              bloc.setUpMap['SearchGender'],
                                          maxAge: SetUpBloc.get(context)
                                              .selectedAgeRange
                                              .end
                                              .toInt(),
                                          minAge: SetUpBloc.get(context)
                                              .selectedAgeRange
                                              .start
                                              .toInt(),
                                          selectionModel: list,
                                          height: double.tryParse(
                                              SetUpBloc.get(context)
                                                  .weightRequiredController
                                                  .text),
                                          weight: double.tryParse(
                                              SetUpBloc.get(context)
                                                  .heightRequiredController
                                                  .text),
                                          isSmoking:
                                              bloc.setUpMap['IsSmoking']);
                                  SetUpBloc.get(context).add(
                                      PostSetUpRequiredEvent(
                                          setupRequiredBody));
                                  debugPrint(
                                      setupRequiredBody.toJson().toString());
                                }
                              },
                              text: Strings.save,
                            ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const CustomAppBar(
                          title: Strings.required_data,
                        ),

                        //  AgeRangeSelector(),
                        const SizedBox(
                          height: 20,
                        ),
                        Expanded(
                          child: ListView(
                            children: [
                              const Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: Strings.search_for,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: context.height * 0.03,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InkWell(
                                      onTap: () {
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "SearchGender", value: 0);
                                      },
                                      child: Container(
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: SetUpBloc.get(context)
                                                                  .setUpMap[
                                                              "SearchGender"] ==
                                                          0
                                                      ? ColorManager
                                                          .primaryColor
                                                      : Colors.grey)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(5),
                                            child:
                                                Image.asset(ImageManager.male),
                                          ))),
                                  SizedBox(
                                    width: context.width * 0.2,
                                  ),
                                  InkWell(
                                      onTap: () {
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "SearchGender", value: 1);
                                      },
                                      child: Container(
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: SetUpBloc.get(context)
                                                                  .setUpMap[
                                                              "SearchGender"] ==
                                                          1
                                                      ? ColorManager
                                                          .primaryColor
                                                      : Colors.grey)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(5),
                                            child: Image.asset(
                                                ImageManager.female),
                                          ))),
                                ],
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              AgeRangeSelector(),
                              const SizedBox(
                                height: 15,
                              ),
                              MainParam(
                                heightController: bloc.heightRequiredController,
                                weightController: bloc.weightRequiredController,
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              ParamsBody(isUpdate: widget.isUpdated),
                            ],
                          ),
                        ),
                      ],
                    )),
          );
        },
      ),
    );
  }
}

class ParamsBody extends StatefulWidget {
  const ParamsBody({super.key, required this.isUpdate});
  final bool? isUpdate;
  @override
  State<ParamsBody> createState() => _ParamsBodyState();
}

class _ParamsBodyState extends State<ParamsBody> {
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates s) {},
      builder: (BuildContext context, SetUpStates s) => BlocConsumer<ParamsBloc,
              SetUpStates>(
          listener: (BuildContext context, SetUpStates state) {
            if (state is GetParamsSuccess) {
              SetUpBloc.get(context).fillSetupCollectList(state.paramsList);
            }
          },
          builder: (BuildContext context, SetUpStates state) => state
                  is GetParamsLoading
              ? const LinearProgressIndicator(
                  color: ColorManager.primaryColor,
                )
              : state is GetParamsSuccess
                  ? Padding(
                      padding: const EdgeInsetsDirectional.only(start: 10),
                      child: Wrap(
                        direction: Axis.horizontal,
                        children: [
                          for (int i = 0; i < state.paramsList.length; i++)
                            Padding(
                              padding: const EdgeInsetsDirectional.only(
                                  end: 10, bottom: 15),
                              child: Container(
                                width:
                                    // state.paramsList[i].type == 0
                                    //     ? (context.width * 0.5) - 45
                                    //     :
                                    (context.width) - 65,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                        Dimensions.buttonRadius),
                                    border: Border.all(
                                        color: ColorManager.primaryColor)),
                                child: Center(
                                    child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 20),
                                        child: state.paramsList[i].type == 0
                                            ? SelectType(
                                                i: i,
                                                paramsList: state.paramsList,
                                              )
                                            : state.paramsList[i].type == 2
                                                ? TextNumberType(
                                                    paramsList:
                                                        state.paramsList,
                                                    isNumber: false,
                                                    i: i,
                                                  )
                                                : state.paramsList[i].type == 4
                                                    ? TextNumberType(
                                                        paramsList:
                                                            state.paramsList,
                                                        isNumber: true,
                                                        i: i,
                                                      )
                                                    : state.paramsList[i]
                                                                .type ==
                                                            3
                                                        ? DateType(
                                                            paramsList: state
                                                                .paramsList,
                                                            i: i,
                                                          )
                                                        : MultiSelectType(
                                                            i: i,
                                                            paramsModel: state
                                                                    .paramsList[
                                                                i]))),
                              ),
                            )
                        ],
                      ),
                    )
                  : const SizedBox()),
    );
  }
}
