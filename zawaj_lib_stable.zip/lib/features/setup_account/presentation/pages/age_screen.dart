import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/features/setup_account/data/models/area_model.dart';
import 'package:zawaj/features/setup_account/data/models/city_model.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/area_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/city_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/marital_screen.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/router/routes.dart';
import '../../../../core/widgets/custom_appbar.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../../../core/widgets/custom_scaffold.dart';
import '../../../../core/widgets/custom_text.dart';
import '../bloc/setup_bloc.dart';
import '../bloc/states.dart';
import '../widgets/custom_radios.dart';

class AgeScreen extends StatelessWidget {
  const AgeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isFullScreen: true,
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const CustomAppBar(
              title: Strings.some_information_about,
              isBack: true,
            ),
            const CustomRadios(2),
            SizedBox(
              height: context.height * 0.09,
            ),
            const Row(
              children: [
                CustomText(
                  text: Strings.birthyear,
                  fontWeight: FontWeight.normal,
                ),
                SizedBox(
                  width: 20,
                ),
                YearDropdownWidget()
                //Expanded(child: BirthYearList())
              ],
            ),
            SizedBox(
              height: context.height * 0.06,
            ),
            const Align(
              alignment: Alignment.topRight,
              child: CustomText(
                text: Strings.whereFrom,
              ),
            ),
            const CustomCityDropDown(),
            const CustomAreaDropDown(),
            const SizedBox(
              height: 12,
            ),
            CustomButton(
              text: Strings.next,
              onTap: () {
                if (SetUpBloc.get(context).setUpMap["BirthYear"] == null) {
                  context.getSnackBar(
                      snackText: 'You must add birthYear', isError: true);
                } else if (SetUpBloc.get(context).setUpMap["CityId"] == null) {
                  context.getSnackBar(
                      snackText: 'You must add City', isError: true);
                } else if (SetUpBloc.get(context).setUpMap["AreaId"] == null) {
                  context.getSnackBar(
                      snackText: 'You must add Area', isError: true);
                } else {
                  MagicRouter.navigateTo(MaritalStatus());
                }
                //SetUpBloc.get(context).changeMapValue(key:"BirthYear" ,value:SetUpBloc.get(context).controllerName.text );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class YearDropdownWidget extends StatefulWidget {
  const YearDropdownWidget({super.key});

  @override
  _YearDropdownWidgetState createState() => _YearDropdownWidgetState();
}

class _YearDropdownWidgetState extends State<YearDropdownWidget> {
  List<int> years = List.generate(
      ((DateTime.now().year - 16) - 1950) + 1, (index) => 1950 + index);

  int? selectedYear;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates state) {},
      builder: (BuildContext context, SetUpStates state) => Container(
        height: Dimensions(context: context).textFieldHeight,
        padding: const EdgeInsets.symmetric(horizontal: 15),
        decoration: BoxDecoration(
            border: Border.all(color: ColorManager.primaryColor),
            borderRadius: BorderRadius.circular(Dimensions.buttonRadius)),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<int>(
            elevation: 0,
            icon: const Icon(
              Icons.keyboard_arrow_down_sharp,
              color: ColorManager.primaryColor,
            ),
            value: SetUpBloc.get(context).setUpMap["BirthYear"],
            items: years.map((int year) {
              return DropdownMenuItem<int>(
                value: year,
                child: Padding(
                  padding: const EdgeInsetsDirectional.only(end: 20),
                  child: Text(
                    '$year',
                    style: const TextStyle(color: ColorManager.primaryColor),
                  ),
                ),
              );
            }).toList(),
            onChanged: (newValue) {
              SetUpBloc.get(context)
                  .changeMapValue(key: "BirthYear", value: newValue);
            },
            hint: const Padding(
              padding: EdgeInsetsDirectional.only(end: 20),
              child: Text(
                Strings.birthyear2,
                style: TextStyle(color: ColorManager.primaryColor),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CustomCityDropDown extends StatelessWidget {
  const CustomCityDropDown({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates s) {},
      builder: (BuildContext context, SetUpStates s) =>
          BlocConsumer<CityBloc, SetUpStates>(
        listener: (context, state) {
          if (state is GetCitySuccess) {
            //SetUpBloc.get(context).dropValueList =
            //  List.filled(state.cityList.length, null);
            print(state.cityList[0].city);
            print("state.cityList[0].city");
          }
        },
        builder: (BuildContext context, SetUpStates state) => state
                is GetCityLoading
            ? const LinearProgressIndicator(
                color: ColorManager.primaryColor,
              )
            : state is GetCitySuccess
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Container(
                      height: Dimensions(context: context).textFieldHeight,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(Dimensions.buttonRadius),
                          border: Border.all(color: ColorManager.primaryColor)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<CityModel>(
                          isExpanded: true,
                          elevation: 0,
                          icon: const Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: ColorManager.primaryColor,
                          ),
                          value: SetUpBloc.get(context).cityDropModel,
                          items: state.cityList.map((CityModel cityValue) {
                            return DropdownMenuItem<CityModel>(
                              value: cityValue,
                              child: Padding(
                                padding:
                                    const EdgeInsetsDirectional.only(start: 5),
                                child: Text(
                                  '${cityValue.city}',
                                  style: const TextStyle(
                                      color: ColorManager.primaryColor),
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (newValue) {
                            SetUpBloc.get(context).changeDropListCity(newValue);
                            SetUpBloc.get(context).changeMapValue(
                                key: "CityId", value: newValue!.id);
                            print(newValue);
                          },
                          hint: const Padding(
                            padding: EdgeInsetsDirectional.only(start: 5),
                            child: Text(
                              Strings.city,
                              style:
                                  TextStyle(color: ColorManager.primaryColor),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                : const SizedBox(),
      ),
    );
  }
}

class CustomAreaDropDown extends StatelessWidget {
  const CustomAreaDropDown({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SetUpBloc, SetUpStates>(
      listener: (BuildContext context, SetUpStates s) {},
      builder: (BuildContext context, SetUpStates s) =>
          BlocConsumer<AreaBloc, SetUpStates>(
        listener: (context, state) {
          if (state is GetCitySuccess) {
            //SetUpBloc.get(context).dropValueList =
            //  List.filled(state.cityList.length, null);
          }
        },
        builder: (BuildContext context, SetUpStates state) => state
                is GetAreaLoading
            ? const LinearProgressIndicator(
                color: ColorManager.primaryColor,
              )
            : state is GetAreaSuccess
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Container(
                      height: Dimensions(context: context).textFieldHeight,
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      decoration: BoxDecoration(
                          borderRadius:
                              BorderRadius.circular(Dimensions.buttonRadius),
                          border: Border.all(color: ColorManager.primaryColor)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<AreaModel>(
                          isExpanded: true,
                          elevation: 0,
                          icon: const Icon(
                            Icons.keyboard_arrow_down_sharp,
                            color: ColorManager.primaryColor,
                          ),
                          value: SetUpBloc.get(context).areaDropModel,
                          items: state.areaList.map((AreaModel areaValue) {
                            return DropdownMenuItem<AreaModel>(
                              value: areaValue,
                              child: Padding(
                                padding:
                                    const EdgeInsetsDirectional.only(start: 5),
                                child: Text(
                                  '${areaValue.area}',
                                  style: const TextStyle(
                                      color: ColorManager.primaryColor),
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (newValue) {
                            SetUpBloc.get(context).changeDropListArea(newValue);
                            SetUpBloc.get(context).changeMapValue(
                                key: "AreaId", value: newValue!.id);
                            print(newValue);
                          },
                          hint: const Padding(
                            padding: EdgeInsetsDirectional.only(end: 5),
                            child: Text(
                              Strings.area,
                              style:
                                  TextStyle(color: ColorManager.primaryColor),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                : const SizedBox(),
      ),
    );
  }
}
