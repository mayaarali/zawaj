
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/extensions/colored_print.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/add_image_box.dart';
import 'package:zawaj/core/widgets/build_dialog.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/setup_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_personal_data.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/custom_appbar.dart';
import '../../../../core/widgets/custom_button.dart';
import '../bloc/states.dart';
import '../widgets/custom_radios.dart';

class ChooseImages extends StatefulWidget {
  const ChooseImages({super.key});

  @override
  State<ChooseImages> createState() => _ChooseImagesState();
}

class _ChooseImagesState extends State<ChooseImages> {
  @override
  void initState() {
    SetUpBloc.get(context).selectedImages = List.filled(3, null);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        isFullScreen: true,
        child: BlocConsumer<SetUpBloc, SetUpStates>(
          listener: (BuildContext context, SetUpStates state) {},
          builder: (BuildContext context, SetUpStates state) => Column(
            children: [
              CustomAppBar(
                title: Strings.add_photos,
                leading: InkWell(
                    onTap: () => buildDialog(
                        onTapEnter: () {
                          MagicRouter.goBack();
                        },
                        buttonTitle: Strings.undersrtand,
                        title: Strings.why_photo,
                        desc: Strings.increase_watchers,
                        context: context),
                    child: const Icon(
                      Icons.info_outline,
                      color: ColorManager.primaryColor,
                    )),
                isBack: true,
              ),
              const CustomRadios(0),
              const SizedBox(
                height: 10,
              ),
              const SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  Expanded(
                    child: AddImageBox(context.height * 0.35, context.width,
                        SetUpBloc.get(context).selectedImages[0], () {
                      SetUpBloc.get(context).removeImage(0);
                    },
                        () => SetUpBloc.get(context)
                            .selectFromGallery(context, 0)),
                  ),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  Expanded(
                      child: AddImageBox(
                          context.height * 0.2,
                          context.height * 0.2,
                          SetUpBloc.get(context).selectedImages[1], () {
                    SetUpBloc.get(context).removeImage(1);
                  }, () {
                    SetUpBloc.get(context).selectFromGallery(context, 1);
                  })),
                  const SizedBox(
                    width: 30,
                  ),
                  Expanded(
                      child: AddImageBox(
                          context.height * 0.2,
                          context.height * 0.2,
                          SetUpBloc.get(context).selectedImages[2], () {
                    SetUpBloc.get(context).removeImage(2);
                  },
                          () => SetUpBloc.get(context)
                              .selectFromGallery(context, 2))),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              CustomButton(
                text: Strings.next,
                onTap: ()async {

                     List images=[];
                    for(int i=0;i<SetUpBloc.get(context).selectedImages.length;i++){

                      if(SetUpBloc.get(context).selectedImages[i]!=null){
                        images.add(await MultipartFile.fromFile(SetUpBloc.get(context).selectedImages[i]!));

                      }

                    }

                    if(images.isEmpty){
                      context.getSnackBar(snackText: 'You must add at least one image',isError: true);
                    }else{
                      SetUpBloc.get(context).setUpMap.addEntries({
                        "ImagesPath":images}.entries);

                      context.printGreen(SetUpBloc.get(context).setUpMap);
                      MagicRouter.navigateTo(
                          const SetPersonalData());
                    }








                }


              ),
            ],
          ),
        ));
  }
}
