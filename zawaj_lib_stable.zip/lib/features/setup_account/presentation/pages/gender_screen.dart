import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/validator/validator.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/custom_text_field.dart';
import 'package:zawaj/core/widgets/toast.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/setup_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/states.dart';
import 'package:zawaj/features/setup_account/presentation/pages/age_screen.dart';

import '../widgets/custom_radios.dart';

class GenderScreen extends StatelessWidget {
  const GenderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        isFullScreen: true,
        child: BlocConsumer<SetUpBloc, SetUpStates>(
          listener: (BuildContext context, SetUpStates state) {},
          builder: (BuildContext context, SetUpStates state) =>
              SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const CustomAppBar(
                  title: Strings.some_information_about,
                  isBack: false,
                ),
                const CustomRadios(3),
                SizedBox(
                  height: context.height * 0.09,
                ),
                const CustomText(
                  text: Strings.me,
                  fontWeight: FontWeight.normal,
                ),
                SizedBox(
                  height: context.height * 0.03,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                        onTap: () {
                          SetUpBloc.get(context)
                              .changeMapValue(key: "Gender", value: 0);
                          SetUpBloc.get(context)
                              .changeMapValue(key: "SearchGender", value: 1);
                        },
                        child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                    color: SetUpBloc.get(context)
                                                .setUpMap["Gender"] ==
                                            0
                                        ? ColorManager.primaryColor
                                        : Colors.grey)),
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: Image.asset(ImageManager.male),
                            ))),
                    SizedBox(
                      width: context.width * 0.2,
                    ),
                    InkWell(
                        onTap: () {
                          SetUpBloc.get(context)
                              .changeMapValue(key: "Gender", value: 1);
                          SetUpBloc.get(context)
                              .changeMapValue(key: "SearchGender", value: 0);
                        },
                        child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                    color: SetUpBloc.get(context)
                                                .setUpMap["Gender"] ==
                                            1
                                        ? ColorManager.primaryColor
                                        : Colors.grey)),
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: Image.asset(ImageManager.female),
                            ))),
                  ],
                ),
                SizedBox(
                  height: context.height * 0.03,
                ),
                const CustomText(
                  text: Strings.search_for,
                  fontWeight: FontWeight.normal,
                ),
                SizedBox(
                  height: context.height * 0.03,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                        onTap: () {
                          SetUpBloc.get(context)
                              .changeMapValue(key: "SearchGender", value: 0);
                          SetUpBloc.get(context)
                              .changeMapValue(key: "Gender", value: 1);
                        },
                        child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                    color: SetUpBloc.get(context)
                                                .setUpMap["SearchGender"] ==
                                            0
                                        ? ColorManager.primaryColor
                                        : Colors.grey)),
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: Image.asset(ImageManager.male),
                            ))),
                    SizedBox(
                      width: context.width * 0.2,
                    ),
                    InkWell(
                        onTap: () {
                          //  // if (SetUpBloc.get(context).setUpMap["Gender"] == 0) {
                          //     SetUpBloc.get(context)
                          //         .changeMapValue(key: "SearchGender", value: 1);
                          //   //} else {
                          //     SetUpBloc.get(context)
                          //         .changeMapValue(key: "SearchGender", value: 0);
                          //   //}
                          SetUpBloc.get(context)
                              .changeMapValue(key: "SearchGender", value: 1);
                          SetUpBloc.get(context)
                              .changeMapValue(key: "Gender", value: 0);
                        },
                        child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                    color: SetUpBloc.get(context)
                                                .setUpMap["SearchGender"] ==
                                            1
                                        ? ColorManager.primaryColor
                                        : Colors.grey)),
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: Image.asset(ImageManager.female),
                            ))),
                  ],
                ),
                SizedBox(
                  height: context.height * 0.06,
                ),
                CustomTextField(
                  controller: SetUpBloc.get(context).controllerName,
                  validate: (v) => Validator.validateName(v),
                  hintText: Strings.my_name,
                ),
                SizedBox(
                  height: context.height * 0.03,
                ),
                CustomButton(
                  text: Strings.next,
                  onTap: () {
                    if (SetUpBloc.get(context).controllerName.text == '') {
                      //  context.getSnackBar(snackText: "You must add Name", isError: true);
                      showToast(
                          msg: 'You must add your name',
                          gravity: ToastGravity.BOTTOM,
                          textColor: ColorManager.primaryColor);
                    } else {
                      SetUpBloc.get(context).changeMapValue(
                          key: "Name",
                          value: SetUpBloc.get(context).controllerName.text);
                      MagicRouter.navigateTo(const AgeScreen());
                    }
                  },
                )
              ],
            ),
          ),
        ));
  }
}
