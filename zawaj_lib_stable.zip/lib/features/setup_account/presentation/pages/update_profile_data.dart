import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/profile/presentation/bloc/profile_bloc.dart';
import 'package:zawaj/features/profile/presentation/bloc/states.dart';
import 'package:zawaj/features/setup_account/data/models/params_model.dart';
import 'package:zawaj/features/setup_account/presentation/bloc/params_bloc.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_personal_data.dart';
import 'package:zawaj/injection_controller.dart' as di;

import '../../../../core/constants/image_manager.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/custom_appbar.dart';
import '../../data/models/setup_required_body.dart';
import '../bloc/setup_bloc.dart';
import '../bloc/states.dart';
import '../widgets/main_params.dart';

class UpdateProfileData extends StatefulWidget {
  UpdateProfileData({super.key});

  @override
  State<UpdateProfileData> createState() => _UpdateProfileDataState();
}

class _UpdateProfileDataState extends State<UpdateProfileData> {
  @override
  void initState() {
    di.sl<ParamsBloc>().getParams();
    ProfileBloc.get(context).getMyProfile();

    super.initState();
  }

  int getBirthYearFromAge(int age) {
    DateTime now = DateTime.now();
    int currentYear = now.year;
    int birthYear = currentYear - age;
    return birthYear;
  }

  void initializeSetUpProfileBody() {
    print('initializeSetUpRequiredBody');
    log(ProfileBloc.get(context).profileData.toString());
    if (ProfileBloc.get(context).profileData != null) {
      print('isUpdated && ProfileBloc.get(context).profileData != null');
      SetUpBloc bloc = SetUpBloc.get(context);
      SetupRequiredBody setupRequiredBody = SetupRequiredBody(
        searchGender:
            ProfileBloc.get(context).profileData!.gender!.toLowerCase() ==
                    "male"
                ? 1
                : 0,
        selectionModel: [],
        height: ProfileBloc.get(context).profileData!.height,
        weight: ProfileBloc.get(context).profileData!.weight,
        isSmoking: ProfileBloc.get(context).profileData!.isSmoking,
        maxAge: null,
        minAge: null,
      );
      SetUpBloc.get(context).heightController.text =
          setupRequiredBody.height.toString();
      SetUpBloc.get(context).weightController.text =
          setupRequiredBody.weight.toString();
      SetUpBloc.get(context).controllerName.text =
          ProfileBloc.get(context).profileData!.name ?? '';
      SetUpBloc.get(context).setUpMap = {
        "Gender": setupRequiredBody.searchGender == 0 ? 1 : 0,
        "SearchGender": setupRequiredBody.searchGender,
        "Name": SetUpBloc.get(context).controllerName.text,
        "BirthYear":
            getBirthYearFromAge(ProfileBloc.get(context).profileData!.age ?? 0),
        "MaritalStatus": 0,
        "CityId": null,
        "AreaId": null,
        "Height": null,
        "Weight": null,
        "IsSmoking": setupRequiredBody.isSmoking,
        "MaxAge": 0,
        "MinAge": 0,
      };

      for (int i = 0;
          i < ProfileBloc.get(context).profileData!.parameters!.length;
          i++) {
        if (ProfileBloc.get(context)
                .profileData!
                .parameters![i]
                .parameterType ==
            1) {
          for (int i1 = 0; i1 < SetUpBloc.get(context).isChecked.length; i1++) {
            if (SetUpBloc.get(context).isChecked[i1] != null) {
              print("checked not null");
              print(SetUpBloc.get(context).isChecked[i1]!);

              for (int i2 = 0;
                  i2 < SetUpBloc.get(context).isChecked[i1]!.length;
                  i2++) {
                print(
                    'valueId===>${ProfileBloc.get(context).profileData!.parameters![i].valueId}');
                print(
                    'isCheckedIndex===>${SetUpBloc.get(context).isChecked[i1]![i2]!.index}');

                if (SetUpBloc.get(context)
                        .isChecked[i1]![i2]!
                        .index
                        .toString() ==
                    ProfileBloc.get(context)
                        .profileData!
                        .parameters![i]
                        .valueId
                        .toString()) {
                  print('iam innnn');
                  SetUpBloc.get(context).isChecked[i1]![i2]!.value = true;
                  setState(() {});
                }
              }
            }
          }
          SetUpBloc.get(context).multiSelectList!.add(
                ValueBody(
                  paramId: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .parameterId,
                  value: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueName,
                  valueId: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueId,
                ),
              );

          print(
              'len multiselect init =${SetUpBloc.get(context).multiSelectList!.length}');
        } else if (ProfileBloc.get(context)
                .profileData!
                .parameters![i]
                .parameterType ==
            0) {
          SetUpBloc.get(context).changeDropList(
              i,
              Value(
                  value: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueName,
                  id: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueId),
              ProfileBloc.get(context).profileData!.parameters![i].parameterId);
        } else {
          print('parameter type not equal 0||1');
          SetUpBloc.get(context).changeDropList(
              i,
              Value(
                  value: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueName,
                  id: ProfileBloc.get(context)
                      .profileData!
                      .parameters![i]
                      .valueId),
              ProfileBloc.get(context).profileData!.parameters![i].parameterId);
          debugPrint(
              "text item update is ${SetUpBloc.get(context).dropValueList![i]}");

          // SetUpBloc.get(context).textParams[i] =
          //     ProfileBloc.get(context).profileData!.parameters![i].valueName.toString();
          // print(SetUpBloc.get(context).textParams[i]);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    SetUpBloc bloc = SetUpBloc.get(context);
    return BlocConsumer<ParamsBloc, SetUpStates>(
      listener: (context, state) {
        print(ProfileBloc.get(context).profileData);
        if (state is GetParamsSuccess) {
          SetUpBloc.get(context).dropValueList =
              List.filled(state.paramsList.length, null);
          SetUpBloc.get(context).dropValueBodyList =
              List.filled(state.paramsList.length, null);
        }
      },
      builder: (context, state) => BlocConsumer<ProfileBloc, ProfileStates>(
        listener: (context, state) {
          print(ProfileBloc.get(context).profileData);
          if (state is SuccessProfile) {
            initializeSetUpProfileBody();
          }
        },
        builder: (context, state) {
          print(ProfileBloc.get(context).profileData);
          return BlocConsumer<SetUpBloc, SetUpStates>(
            listener: (BuildContext context, SetUpStates state) {
              if (state is SuccessRequiredSetUp) {
                MagicRouter.navigateAndReplacement(const DashBoardScreen(
                  initialIndex: 2,
                ));
              }
              if (state is FailedRequiredSetUp) {
                context.getSnackBar(snackText: state.message, isError: true);
              }
            },
            builder: (BuildContext context, SetUpStates state) =>
                CustomScaffold(
                    isFullScreen: true,
                    bottomNavigationBar: Padding(
                      padding: const EdgeInsets.all(Dimensions.defaultPadding),
                      child: state is LoadingRequiredSetUp
                          ? SizedBox(
                              height: Dimensions(context: context).buttonHeight,
                              child: const LoadingCircle())
                          : CustomButton(
                              onTap: () async {
                                await SetUpBloc.get(context).changeMapValue(
                                    key: "Height",
                                    value: double.tryParse(
                                        SetUpBloc.get(context)
                                            .heightController
                                            .text));
                                await SetUpBloc.get(context).changeMapValue(
                                    key: "Weight",
                                    value: double.tryParse(
                                        SetUpBloc.get(context)
                                            .weightController
                                            .text));

                                List<ValueBody?> list = [];
                                for (int i = 0;
                                    i <
                                        SetUpBloc.get(context)
                                            .dropValueBodyList!
                                            .length;
                                    i++) {
                                  if (SetUpBloc.get(context)
                                          .dropValueBodyList![i] !=
                                      null) {
                                    list.add(SetUpBloc.get(context)
                                        .dropValueBodyList![i]);
                                  }
                                }
                                for (var element in SetUpBloc.get(context)
                                    .multiSelectList!) {
                                  list.add(element);
                                }

                                SetUpBloc.get(context).setUpMap.addEntries({
                                      "selectionModel": List<dynamic>.from(
                                          list.map((x) => x!.toJson()))
                                    }.entries);

                                debugPrint(
                                    SetUpBloc.get(context).setUpMap.toString());
                                if (SetUpBloc.get(context).setUpMap["Height"] ==
                                    null) {
                                  context.getSnackBar(
                                      snackText: 'You must add Height',
                                      isError: true);
                                } else if (SetUpBloc.get(context)
                                        .setUpMap["Weight"] ==
                                    null) {
                                  context.getSnackBar(
                                      snackText: 'You must add Weight',
                                      isError: true);
                                } else {
                                  debugPrint(
                                      "setup body ${SetUpBloc.get(context).setUpMap}");
                                  // SetUpBloc.get(context).add(PostSetUpEvent());
                                }
                              },
                              text: Strings.save,
                            ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const CustomAppBar(
                          title: Strings.required_data,
                        ),

                        //  AgeRangeSelector(),
                        const SizedBox(
                          height: 20,
                        ),
                        Expanded(
                          child: ListView(
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      InkWell(
                                          onTap: () {
                                            SetUpBloc.get(context)
                                                .changeMapValue(
                                                    key: "Gender", value: 0);
                                            SetUpBloc.get(context)
                                                .changeMapValue(
                                                    key: "SearchGender",
                                                    value: 1);
                                          },
                                          child: Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                  border: Border.all(
                                                      color: SetUpBloc.get(
                                                                          context)
                                                                      .setUpMap[
                                                                  "Gender"] ==
                                                              0
                                                          ? ColorManager
                                                              .primaryColor
                                                          : Colors.grey)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(5),
                                                child: Image.asset(
                                                    ImageManager.male),
                                              ))),
                                      SizedBox(
                                        width: context.width * 0.2,
                                      ),
                                      InkWell(
                                          onTap: () {
                                            SetUpBloc.get(context)
                                                .changeMapValue(
                                                    key: "Gender", value: 1);
                                            SetUpBloc.get(context)
                                                .changeMapValue(
                                                    key: "SearchGender",
                                                    value: 0);
                                          },
                                          child: Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                  border: Border.all(
                                                      color: SetUpBloc.get(
                                                                          context)
                                                                      .setUpMap[
                                                                  "Gender"] ==
                                                              1
                                                          ? ColorManager
                                                              .primaryColor
                                                          : Colors.grey)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(5),
                                                child: Image.asset(
                                                    ImageManager.female),
                                              ))),
                                    ],
                                  ),
                                  SizedBox(
                                    height: context.height * 0.03,
                                  ),
                                  CustomText(
                                    text: Strings.search_for,
                                    fontWeight: FontWeight.normal,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: context.height * 0.03,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InkWell(
                                      onTap: () {
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "SearchGender", value: 0);
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "Gender", value: 1);
                                      },
                                      child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                              border: Border.all(
                                                  color: SetUpBloc.get(context)
                                                                  .setUpMap[
                                                              "SearchGender"] ==
                                                          0
                                                      ? ColorManager
                                                          .primaryColor
                                                      : Colors.grey)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(5),
                                            child:
                                                Image.asset(ImageManager.male),
                                          ))),
                                  SizedBox(
                                    width: context.width * 0.2,
                                  ),
                                  InkWell(
                                      onTap: () {
                                        //  // if (SetUpBloc.get(context).setUpMap["Gender"] == 0) {
                                        //     SetUpBloc.get(context)
                                        //         .changeMapValue(key: "SearchGender", value: 1);
                                        //   //} else {
                                        //     SetUpBloc.get(context)
                                        //         .changeMapValue(key: "SearchGender", value: 0);
                                        //   //}
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "SearchGender", value: 1);
                                        SetUpBloc.get(context).changeMapValue(
                                            key: "Gender", value: 0);
                                      },
                                      child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(8),
                                              border: Border.all(
                                                  color: SetUpBloc.get(context)
                                                                  .setUpMap[
                                                              "SearchGender"] ==
                                                          1
                                                      ? ColorManager
                                                          .primaryColor
                                                      : Colors.grey)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(5),
                                            child: Image.asset(
                                                ImageManager.female),
                                          ))),
                                ],
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              MainParam(
                                heightController: bloc.heightController,
                                weightController: bloc.weightController,
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              const ParamsBody(),
                            ],
                          ),
                        ),
                      ],
                    )),
          );
        },
      ),
    );
  }
}
