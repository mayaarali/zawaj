import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';

class CustomExpandedPanel extends StatelessWidget {
  const CustomExpandedPanel(
      {super.key, required this.header, required this.expanded});
  final Widget expanded;
  final Widget header;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(Dimensions.buttonRadius),
              border: Border.all(color: ColorManager.primaryColor)),
          child: ExpandablePanel(
            theme:
                const ExpandableThemeData(iconColor: ColorManager.primaryColor),
            header: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  header,
                ],
              ),
            ),
            collapsed: const SizedBox(),
            expanded: expanded,
          )),
    );
  }
}
