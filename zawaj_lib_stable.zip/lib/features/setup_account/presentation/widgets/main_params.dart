import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/custom_text.dart';
import '../bloc/setup_bloc.dart';
import '../bloc/states.dart';
import 'custom_expandable_panel.dart';
import 'custom_is_smoking.dart';

class MainParam extends StatelessWidget {
  const MainParam(
      {super.key,
      required this.weightController,
      required this.heightController});
  final TextEditingController weightController;
  final TextEditingController heightController;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: CustomExpandedPanel(
                header: const CustomText(
                  text: Strings.height,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                expanded: Column(
                  children: [
                    TextField(
                      controller: heightController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: ""),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Expanded(
              child: CustomExpandedPanel(
                header: const CustomText(
                  text: Strings.weight,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                expanded: Column(
                  children: [
                    TextField(
                      controller: weightController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(hintText: ""),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
        const SizedBox(
          height: 15,
        ),
        BlocConsumer<SetUpBloc, SetUpStates>(
          listener: (context, state) {},
          builder: (context, state) {
            return CustomExpandedPanel(
              header: const CustomText(
                text: Strings.isSmoking,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
              expanded: CustomisSmoking(),
            );
          },
        )
      ],
    );
  }
}
