import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/helper/api_error_handler.dart';
import 'package:zawaj/core/network/network_info.dart';
import 'package:zawaj/features/favorites/data/data_source/favorites_datasource.dart';
import 'package:zawaj/features/favorites/data/models/favorites_model.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';

class LikedPartnersRepositoryImp {
  LikedPartnersDataSourceImp likedPartnersDataSourceImp;
  NetworkInfo networkInfo;
  LikedPartnersRepositoryImp({
    required this.likedPartnersDataSourceImp,
    required this.networkInfo,
  });

  Future<Either<String, List<HomeModel>>> likedPartners() async {
    List<HomeModel> homeModel = [];
    if (await networkInfo.isConnected) {
      try {
        Response response = await likedPartnersDataSourceImp.likedPartners();

        if (response.statusCode == 200) {
          homeModel = [];
          response.data!.forEach((e) {
            homeModel.add(HomeModel.fromJson(e));
          });

          return Right(homeModel);
        } else {
          return Left(ApiExceptionHandler.getMessage(response));
        }
      } on DioException catch (error) {
        return Left(ApiExceptionHandler.getMessage(error));
      }
    } else {
      return const Left(Strings.nointernet);
    }
  }
}
