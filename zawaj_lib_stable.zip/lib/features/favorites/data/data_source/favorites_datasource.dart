import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/helper/dio_helper.dart';

class LikedPartnersDataSourceImp {
  @override
  DioHelper apiClientHelper;
  LikedPartnersDataSourceImp({required this.apiClientHelper});

  Future likedPartners() {
    return apiClientHelper.getData(url: EndPoints.likedPartners);
  }
}
