part of 'favorites_post_bloc.dart';

abstract class LikedPartnersEvent {}

class LikedPartners extends LikedPartnersEvent {}
