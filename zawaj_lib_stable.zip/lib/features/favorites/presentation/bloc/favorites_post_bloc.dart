import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/favorites/data/repository/favorites_repo.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
part 'favorites_post_event.dart';
part 'favorites_post_state.dart';

class LikedPartnersBloc extends Bloc<LikedPartnersEvent, LikedPartnersStates> {
  static LikedPartnersBloc get(context) => BlocProvider.of(context);
  LikedPartnersRepositoryImp likedPartnersRepositoryImp;
  LikedPartnersBloc({required this.likedPartnersRepositoryImp})
      : super(LikedPartnersInitial()) {
    on<LikedPartnersEvent>((event, emit) async {
      emit(LikedPartnersLoading());
      var response = await likedPartnersRepositoryImp.likedPartners();

      response.fold((failure) {
        emit(LikedPartnersFailed(message: failure));
      }, (homeModel) {
        emit(LikedPartnersSuccess(homeModel));
      });
    });
  }
}
