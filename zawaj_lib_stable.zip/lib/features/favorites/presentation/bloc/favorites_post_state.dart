part of 'favorites_post_bloc.dart';

abstract class LikedPartnersStates {}

final class LikedPartnersInitial extends LikedPartnersStates {}

final class LikedPartnersLoading extends LikedPartnersStates {}

final class LikedPartnersSuccess extends LikedPartnersStates {
  List<HomeModel> homeModel;
  LikedPartnersSuccess(this.homeModel);
}

final class LikedPartnersFailed extends LikedPartnersStates {
  String message;
  LikedPartnersFailed({required this.message});
}
