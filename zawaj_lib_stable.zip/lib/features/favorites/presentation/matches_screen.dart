import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/core/widgets/loading_popup.dart';
import 'package:zawaj/features/chat/presentation/screens/chat_screen.dart';
import 'package:zawaj/features/favorites/presentation/bloc/favorites_post_bloc.dart';
import 'package:zawaj/features/home/data/models/home_model.dart';
import 'package:zawaj/features/home/presentation/blocs/home_bloc/home_bloc.dart';
import 'package:zawaj/features/home/presentation/pages/partner_details_screen.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_report/presentation/screen/send_report.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';

import '../../../core/constants/color_manager.dart';
import '../../../core/router/routes.dart';

class MatchesScreen extends StatefulWidget {
  const MatchesScreen({
    super.key,
    //required this.homeModel
  });
  // final HomeModel homeModel;
  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> {
  @override
  void initState() {
    super.initState();
    final likedPartnersBloc = BlocProvider.of<LikedPartnersBloc>(context);
    likedPartnersBloc.add(LikedPartners());
    BlocProvider.of<HomeBloc>(context).getHomeData();
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        isFullScreen: true,
        child: Column(
          children: [
            CustomAppBar(
                isBack: false,
                isHeartTitle: true,
                leading: GestureDetector(
                  onTap: () {
                    MagicRouter.navigateTo(SetPartnerData(isUpdated: true));
                  },
                  child: SvgPicture.asset(
                    ImageManager.settingIcon,
                    fit: BoxFit.scaleDown,
                  ),
                )),
            BlocConsumer<HomeBloc, HomeState>(
              listener: (context, state) {
                print(BlocProvider.of<HomeBloc>(context).homeModel);
              },
              builder: (context, state) {
                return BlocConsumer<LikedPartnersBloc, LikedPartnersStates>(
                  listener: (context, state) {},
                  builder: (context, state) => state is LikedPartnersLoading
                      ? const LoadingPopUp()
                      : state is LikedPartnersSuccess
                          ?
                          /*
                                  Container(
                                      color: Colors.amber,
                                      height: 50,
                                      width: 50,
                                    )
                                    */
                          state.homeModel.isEmpty
                              ? const Expanded(
                                  child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    CustomText(text: 'Favourite is Empty'),
                                  ],
                                ))
                              : Expanded(
                                  child: SingleChildScrollView(
                                    child: Column(
                                      children: [
                                        ListView.builder(
                                          shrinkWrap: true,
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          itemCount: state.homeModel.length,
                                          itemBuilder: (BuildContext context,
                                              int index) {
                                            return LikedPostWidget(
                                              homeModel: state.homeModel[index],
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                          : Container(
                              height: 100,
                              width: 100,
                              // color: Colors.yellow,
                            ),
                );
              },
            )

            //   const LikedPostWidget(),
          ],
        ));
  }
}

class LikedPostWidget extends StatelessWidget {
  const LikedPostWidget({
    super.key,
    required this.homeModel,
  });
  final HomeModel homeModel;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          alignment: AlignmentDirectional.bottomEnd,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: GestureDetector(
                onTap: () {
                  MagicRouter.navigateTo(
                      PartnerDetailsScreen(homeModel: homeModel));
                },
                child: Image.network(
                    EndPoints.BASE_URL_image + homeModel.images![0],
                    width: context.width,
                    height: context.height * 0.5,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                  return const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(child: Icon(Icons.error)),
                    ],
                  );
                }, frameBuilder:
                        (context, child, frame, wasSynchronouslyLoaded) {
                  return child;
                }, loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) {
                    return child;
                  } else {
                    return const Center(
                      child: LoadingCircle(),
                    );
                  }
                }),
              ),
            ),

            /*
            CachedNetworkImage(
              imageUrl: EndPoints.BASE_URL_image + homeModel.images![0],
              width: context.width,
              height: context.height * 0.5,
              fit: BoxFit.fill,
              errorWidget: (context, url, error) =>
                  const Icon(Icons.error_outline_rounded),
            ),
        */
            /*
            Image.asset(
              'assets/images/user.png',
              width: context.width,
              height: context.height * 0.5,
              fit: BoxFit.fill,
            ),
            */
            Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                children: [
                  Card(
                    color: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)),
                    child: GestureDetector(
                      onTap: () {
                        MagicRouter.navigateTo(SendReport(
                          userId: homeModel.userId!,
                        ));
                      },
                      child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.5)),
                          child: SvgPicture.asset(
                            ImageManager.closeIcon,
                            width: 14,
                            height: 14,
                            fit: BoxFit.scaleDown,
                          )),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      MagicRouter.navigateTo(ChatScreen(
                        receiverId: homeModel.userId!,
                        receiverProdileImage: homeModel.images![0],
                      ));
                    },
                    child: Card(
                      color: Colors.white.withOpacity(0.1),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40)),
                      child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                              //  image: DecorationImage(
                              // image:
                              //      AssetImage(ImageManager.circularBackground)),
                              shape: BoxShape.circle,
                              color: Colors.white.withOpacity(0.5)),
                          child: SvgPicture.asset(
                            ImageManager.chatIcon,
                            width: 14,
                            height: 14,
                            fit: BoxFit.scaleDown,
                          )),
                    ),
                  ),
                  Card(
                    color: Colors.white.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(40)),
                    child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                            //  image: DecorationImage(
                            // image:
                            //      AssetImage(ImageManager.circularBackground)),
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.5)),
                        child: const Icon(
                          Icons.favorite,
                          color: ColorManager.primaryColor,
                        )
                        /*
                        SvgPicture.asset(
                          ImageManager.favIcon,
                          width: 14,
                          height: 14,
                          fit: BoxFit.scaleDown,
                        )
                        */
                        ),
                  ),
                ],
              ),
            )
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomText(
              text: homeModel.name,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              width: 15,
            ),
            CustomText(
              text: homeModel.about,
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
                child: CustomText(
              text: homeModel.city,
              fontSize: Dimensions.normalFont,
              align: TextAlign.start,
            )),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }
}
