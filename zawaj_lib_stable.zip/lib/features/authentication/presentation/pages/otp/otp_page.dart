import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_bloc.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_event.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_states.dart';
import 'package:zawaj/features/authentication/presentation/pages/new_password/reenter_password.dart';
import '../../../../../core/widgets/custom_text.dart';
import '../../widgets/pin_code_widgets.dart';

class OTPPage extends StatelessWidget {
  const OTPPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        child: Padding(
      padding: const EdgeInsets.all(Dimensions.defaultPadding),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const CustomAppBar(
              title: Strings.enter_otp,
            ),
            const SizedBox(
              height: 50,
            ),

            const Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomText(
                  text: Strings.enter_otp_from_email,
                  align: TextAlign.start,
                ),
              ],
            ),
            const SizedBox(
              height: 30,
            ),

            BlocConsumer<AuthBloc, AuthStates>(
              listener: (context, state) {},
              builder: (context, state) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: PinCodeWidget(
                    controller: AuthBloc.get(context).oTPController,
                  ),
                );
              },
            ),

            CustomButton(
                onTap: () {
                  final otpController = AuthBloc.get(context).oTPController;
                  if (otpController.text.isNotEmpty) {
                    MagicRouter.navigateAndPopUntilFirstPage(
                        ReEnterPasswordPage());
                  }
                  if (otpController.text.isEmpty) {
                    context.getSnackBar(snackText: 'Please Enter OTP');
                  }
                },
                text: Strings.next),
            //  const SizedBox(height: context.height*0.1,),
            const SizedBox(
              height: 30,
            ),
            GestureDetector(
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomText(
                    text: Strings.dont_receive_code,
                    align: TextAlign.start,
                  ),
                ],
              ),
              onTap: () {
                AuthBloc.get(context).add(SendEmailEvent());
              },
            ),
          ],
        ),
      ),
    ));
  }
}
