import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/helper/cache_helper.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_bloc.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_states.dart';
import 'package:zawaj/features/authentication/presentation/pages/login_signup/signup_page.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/setup_account/presentation/pages/gender_screen.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';
import '../../../../../core/validator/validator.dart';
import '../../../../../core/widgets/custom_text_field.dart';
import '../../../../../core/widgets/loading_circle.dart';
import '../../bloc/auth_event.dart';
import '../../widgets/facebook_login_btn.dart';
import '../../widgets/google_login_btn.dart';
import '../reset_password/reset_password.dart';
part 'units/login_buttons.dart';
part 'units/login_form.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  static final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        child: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(Dimensions.defaultPadding),
        child: Column(
          children: [
            const CustomAppBar(
              isLogoTitle: true,
              isBack: false,
            ),
            const SizedBox(
              height: 15,
            ),
            const CustomText(
              text: Strings.welcome_back,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              height: 15,
            ),
            const CustomText(
              text: Strings.login_to_reach_account,
              fontSize: Dimensions.smallFont,
            ),
            Form(key: loginFormKey, child: const LoginForm()),
            InkWell(
              onTap: () {
                MagicRouter.navigateTo(const ResetPasswordPage());
              },
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: Strings.forget_password,
                    fontSize: Dimensions.smallFont,
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            BlocConsumer<AuthBloc, AuthStates>(
              listener: (BuildContext context, AuthStates state) async {
                if (state is AuthSuccess) {
                  bool hasSetup =
                      await CacheHelper.getData(key: Strings.hasSetup) ?? false;
                  bool hasRequired =
                      await CacheHelper.getData(key: Strings.hasRequired) ??
                          false;
                  print('looooogin setup========>$hasSetup');
                  print('looooogin Required========>$hasRequired');

                  if (hasRequired) {
                    MagicRouter.navigateAndReplacement(const DashBoardScreen(
                      initialIndex: 2,
                    ));
                  } else if (hasSetup) {
                    MagicRouter.navigateAndReplacement(SetPartnerData(
                      isUpdated: false,
                    ));
                  } else {
                    MagicRouter.navigateAndReplacement(const GenderScreen());
                  }
                }
              },
              builder: (BuildContext context, AuthStates state) => state
                      is LoadingAuth
                  ? const LoadingCircle()
                  : CustomButton(
                      onTap: () {
                        if (loginFormKey.currentState!.validate()) {
                          AuthBloc.get(context).add(LoginEvent(
                              email: AuthBloc.get(context).emailController.text,
                              pass: AuthBloc.get(context)
                                  .passwordController
                                  .text));
                        }
                      },
                      text: Strings.next),
            ),
            const SizedBox(
              height: 30,
            ),
            const Row(
              children: [
                Expanded(
                    child: Divider(
                  color: ColorManager.secondaryPinkColor,
                )),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: CustomText(text: Strings.or),
                ),
                Expanded(
                    child: Divider(
                  color: ColorManager.secondaryPinkColor,
                )),
              ],
            ),
            const LoginButtons(),
            Column(
              children: [
                const CustomText(
                  text: Strings.have_no_account,
                  fontSize: Dimensions.normalFont,
                ),
                const SizedBox(
                  height: 5,
                ),
                InkWell(
                    onTap: () {
                      MagicRouter.navigateAndReplacement(const SignUpPage());
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomText(
                          text: Strings.the_login,
                          fontSize: Dimensions.normalFont,
                          textDecoration: TextDecoration.underline,
                        ),
                      ],
                    )),
              ],
            ),
          ],
        ),
      ),
    ));
  }
}
