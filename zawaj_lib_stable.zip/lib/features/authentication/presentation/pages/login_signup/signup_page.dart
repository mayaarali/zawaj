import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_bloc.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_event.dart';
import 'package:zawaj/features/authentication/presentation/pages/login_signup/login_page.dart';
import 'package:zawaj/features/setup_account/presentation/pages/gender_screen.dart';
import '../../../../../core/validator/validator.dart';
import '../../../../../core/widgets/custom_text_field.dart';
import '../../../../../core/widgets/loading_circle.dart';
import '../../bloc/auth_states.dart';
import '../../widgets/facebook_login_btn.dart';
import '../../widgets/google_login_btn.dart';
part 'units/signup_buttons.dart';
part 'units/signup_forms.dart';

class SignUpPage extends StatelessWidget {
  const SignUpPage({super.key});
  static final GlobalKey<FormState> signupFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        child: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(Dimensions.defaultPadding),
        child: Column(
          children: [
            const CustomAppBar(
              isLogoTitle: true,
              isBack: false,
            ),
            const SizedBox(
              height: 25,
            ),
            const CustomText(
              text: Strings.welcome,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              height: 20,
            ),
            const CustomText(
              text: Strings.create_account,
              fontSize: Dimensions.smallFont,
            ),
            const SocialMediaSignupButtons(),
            const Row(
              children: [
                Expanded(
                    child: Divider(
                  color: ColorManager.secondaryPinkColor,
                )),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: CustomText(text: Strings.or),
                ),
                Expanded(
                    child: Divider(
                  color: ColorManager.secondaryPinkColor,
                )),
              ],
            ),
            Form(key: signupFormKey, child: const SignUpForms()),
            BlocConsumer<AuthBloc, AuthStates>(
              listener: (BuildContext context, AuthStates state) {
                if (state is AuthSuccess) {
                  MagicRouter.navigateAndPopAll(const GenderScreen());
                }
              },
              builder: (BuildContext context, AuthStates state) =>
                  state is LoadingAuth
                      ? const LoadingCircle()
                      : CustomButton(
                          onTap: () {
                            if (signupFormKey.currentState!.validate()) {
                              AuthBloc.get(context).add(RegisterEvent());
                            }
                          },
                          text: Strings.login),
            ),
            const SizedBox(
              height: 10,
            ),
            const SignUpButtons()
          ],
        ),
      ),
    ));
  }
}
