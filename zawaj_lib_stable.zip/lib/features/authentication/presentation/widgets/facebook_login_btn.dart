import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/helper/cache_helper.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/toast.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_bloc.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_event.dart';
import 'package:zawaj/features/authentication/presentation/bloc/auth_states.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/setup_account/presentation/pages/gender_screen.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';
import '../../../../core/constants/dimensions.dart';
import '../../../../core/constants/image_manager.dart';
import '../../../../core/constants/strings.dart';
import '../../../../core/widgets/custom_button.dart';

class FaceBookLogin extends StatelessWidget {
  const FaceBookLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Dimensions.buttonRadius)),
        child: BlocConsumer<AuthBloc, AuthStates>(
          listener: (context, state) async {
            if (state is AuthSuccess) {
              bool hasSetup =
                  await CacheHelper.getData(key: Strings.hasSetup) ?? false;
              bool hasRequired =
                  await CacheHelper.getData(key: Strings.hasRequired) ?? false;
              print('looooogin setup========>$hasSetup');
              print('looooogin Required========>$hasRequired');

              if (hasRequired) {
                MagicRouter.navigateAndReplacement(const DashBoardScreen(
                  initialIndex: 2,
                ));
              } else if (hasSetup) {
                MagicRouter.navigateAndReplacement(SetPartnerData(
                  isUpdated: false,
                ));
              } else {
                MagicRouter.navigateAndReplacement(const GenderScreen());
              }
            } else if (state is AuthFailed) {
              showToast(msg: "Failed! Please Try Again");
            } else if (state is SocialLoginFail) {
              showToast(
                  msg: "Something went wrong! Please Try Again",
                  gravity: ToastGravity.BOTTOM,
                  background: ColorManager.primaryColor,
                  textColor: ColorManager.secondaryPinkColor);
            }
          },
          builder: (BuildContext context, AuthStates state) =>
              state is LoadingAuth
                  ? const SizedBox()
                  : CustomButton(
                      onTap: () {
                        AuthBloc.get(context).add(FacebookLoginEvent());
                        //  AuthBloc.get(context).signInWithFacebook();
                      },
                      text: Strings.facebook_sign_in,
                      color: const Color(0xff1877F2),
                      iconWidget: Image.asset(ImageManager.facebook),
                      height: Dimensions(context: context).textFieldHeight,
                    ),
        ));
  }
}
