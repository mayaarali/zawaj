class AuthStates {}

class GetSecure extends AuthStates {
  bool isSecure;
  GetSecure(this.isSecure);
}

class InitStates extends AuthStates {}

class LoadingAuth extends AuthStates {}

class SocialLoginFail extends AuthStates {}

class GoogleLoginFail extends AuthStates {}

class LoadingAuthOtp extends AuthStates {}

class SuccessAuthOtp extends AuthStates {
  String message;
  SuccessAuthOtp({required this.message});
}

class AuthFailed extends AuthStates {
  String message;
  AuthFailed({required this.message});
}

class AuthSuccess extends AuthStates {
  String message;
  AuthSuccess({required this.message});
}

class DeleteAccountSuccess extends AuthStates {
  String message;
  DeleteAccountSuccess({required this.message});
}

class ChangePasswordSuccess extends AuthStates {
  String message;
  ChangePasswordSuccess({required this.message});
}

class SendEmailLoadingAuth extends AuthStates {}

class SendEmailSuccess extends AuthStates {
  String message;
  SendEmailSuccess({required this.message});
}

class SendEmailFailed extends AuthStates {
  String message;
  SendEmailFailed({required this.message});
}

class ResetPasswordLoadingAuth extends AuthStates {}

class ResetPasswordSuccess extends AuthStates {
  String message;
  ResetPasswordSuccess({required this.message});
}

class ResetPasswordFailed extends AuthStates {
  String message;
  ResetPasswordFailed({required this.message});
}

class ImageCamera extends AuthStates {}

class ImageGallery extends AuthStates {}
