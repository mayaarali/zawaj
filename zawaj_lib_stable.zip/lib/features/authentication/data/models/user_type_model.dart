class UserTypeModel {
  int id ;
  String icon ;
  String typeName ;

  UserTypeModel({required this.id, required this.icon, required this.typeName});
}