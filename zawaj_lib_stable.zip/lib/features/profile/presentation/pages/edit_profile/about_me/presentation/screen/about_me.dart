import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text_field.dart';
import 'package:zawaj/features/profile/data/models/profile_model.dart';
import 'package:zawaj/features/profile/presentation/bloc/states.dart';
import 'package:zawaj/features/profile/presentation/pages/edit_profile/about_me/data/model/model.dart';
import 'package:zawaj/features/profile/presentation/pages/edit_profile/about_me/presentation/cubit/cubit.dart';

import '../../../../../../../../core/constants/color_manager.dart';
import '../../../../../../../../core/constants/dimensions.dart';
import '../../../../../../../../core/widgets/custom_button.dart';
import '../../../../../bloc/profile_bloc.dart';

class AboutMe extends StatefulWidget {
  AboutMe({super.key});

  @override
  State<AboutMe> createState() => _AboutMeState();
}

class _AboutMeState extends State<AboutMe> {
  final TextEditingController _aboutMecontroller = TextEditingController();
  @override
  void initState() {
    ProfileBloc.get(context).profileData;
    //  updateAboutMeText(ProfileBloc.get(context).profileData);
    super.initState();
  }

  void updateAboutMeText(ProfileData? profileData) {
    if (profileData == null || profileData.about == null) {
      _aboutMecontroller.text = Strings.write_about_yourself;
    } else {
      _aboutMecontroller.text = profileData.about.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AboutCubit(),
      child: BlocConsumer<AboutCubit, AboutState>(
        listener: (context, state) {
          ProfileBloc.get(context).profileData == null
              ? Strings.write_about_yourself
              : ProfileBloc.get(context).profileData!.about.toString() == 'null'
                  ? Strings.write_about_yourself
                  : ProfileBloc.get(context).profileData!.about.toString();
          if (state is AboutSuccess) {
            context.getSnackBar(
              snackText: Strings.aboutAddedSuccessfully,
              isError: false,
            );
          } else if (state is AboutError) {
            context.getSnackBar(
              snackText: Strings.error,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return CustomScaffold(
              isFullScreen: true,
              child: Column(
                children: [
                  const CustomAppBar(
                    title: Strings.about_me,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  BlocConsumer<ProfileBloc, ProfileStates>(
                    listener: (context, state) {
                      if (state is SuccessProfile) {
                        updateAboutMeText(state.profileData);
                      }
                    },
                    builder: (context, state) {
                      return CustomTextField(
                        controller: _aboutMecontroller,
                        hintText: ProfileBloc.get(context).profileData == null
                            ? Strings.write_about_yourself
                            : ProfileBloc.get(context)
                                        .profileData!
                                        .about
                                        .toString() ==
                                    'null'
                                ? Strings.write_about_yourself
                                : ProfileBloc.get(context)
                                    .profileData!
                                    .about
                                    .toString(),
                        maxLines: 5,
                        height:
                            Dimensions(context: context).textFieldHeight * 3,
                      );
                    },
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  CustomButton(
                      onTap: () {
                        final data = AboutMeData(_aboutMecontroller.text);
                        context.read<AboutCubit>().addAbout(data);
                        ProfileBloc.get(context).profileData;
                      },
                      text: Strings.save),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomButton(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    text: Strings.skip,
                    txtColor: ColorManager.primaryColor,
                    borderColor: ColorManager.primaryColor,
                    color: Colors.white,
                  ),
                ],
              ));
        },
      ),
    );
  }
}
