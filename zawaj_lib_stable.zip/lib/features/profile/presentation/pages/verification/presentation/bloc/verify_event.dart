part of 'verify_bloc.dart';

abstract class VerifyEvent {}

class Verification extends VerifyEvent {}
