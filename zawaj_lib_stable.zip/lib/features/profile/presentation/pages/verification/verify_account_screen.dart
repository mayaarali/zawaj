import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/add_image_box.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/profile/presentation/pages/verification/presentation/bloc/verify_bloc.dart';

class VerifyScreen extends StatefulWidget {
  const VerifyScreen({super.key});

  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  @override
  void initState() {
    //VerifyBloc.get(context).selectFromGallery(context, 0);
    // var verifyBloc = VerifyBloc.get(context);
    //verifyBloc.add(Verification());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print(
      VerifyBloc.get(context).image1,
    );
    print(
      VerifyBloc.get(context).image2,
    );

    return CustomScaffold(
      isFullScreen: true,
      child: Column(
        children: [
          const CustomAppBar(
            isBack: true,
            isHeartTitle: true,
          ),
          BlocConsumer<VerifyBloc, VerifyState>(
              listener: (context, state) {
                if (state is VerifySuccess) {
                  //  MagicRouter.navigateTo(const ProfilePage());
                  MagicRouter.navigateTo(
                      const DashBoardScreen(initialIndex: 4));
                }
              },
              builder: (context, state) =>
                  //state is VerifyLoading
                  //  ? const LoadingCircle()
                  // : state is VerifySuccess
                  //?
                  Column(
                    children: [
                      AddImageBox(context.height * 0.25, context.width,
                          VerifyBloc.get(context).image1, () {
                        VerifyBloc.get(context).removeImage(0);
                      }, () {
                        VerifyBloc.get(context).selectFromGallery(context, 0);
                      }),
                      const SizedBox(
                        height: 15,
                      ),
                      AddImageBox(context.height * 0.25, context.width,
                          VerifyBloc.get(context).image2, () {
                        VerifyBloc.get(context).removeImage(1);
                      }, () {
                        VerifyBloc.get(context).selectFromGallery(context, 1);
                      }),
                      const SizedBox(
                        height: 100,
                      ),
                      if (state is VerifyLoading)
                        const SizedBox(child: LoadingCircle())
                      else if (state is VerifySuccess)
                        Text(
                          state.message,
                          style: const TextStyle(
                            color: Colors.green,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      else if (state is VerifyFailure)
                        Text(
                          state.message,
                          style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      state is VerifyLoading
                          ? const SizedBox()
                          : CustomButton(
                              onTap: () {
                                VerifyBloc.get(context).add(Verification());
                              },
                              text: "done")
                    ],
                  )
              //:
              /*
                      Container(
                          width: 100,
                          height: 100,
                          color: Colors.amber,
                        )*/
              ),
        ],
      ),
    );
  }
}
