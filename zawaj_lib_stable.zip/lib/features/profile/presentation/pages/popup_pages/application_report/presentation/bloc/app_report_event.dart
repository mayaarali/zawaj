part of 'app_report_bloc.dart';

abstract class AppReportEvent {}

class AppEvent extends AppReportEvent {}
