import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/application_report/presentation/bloc/app_report_bloc.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/application_report/presentation/bloc/app_report_state.dart';

import '../../../../../../../../../core/constants/dimensions.dart';
import '../../../../../../../../../core/constants/strings.dart';
import '../../../../../../../../../core/widgets/custom_appbar.dart';
import '../../../../../../../../../core/widgets/custom_button.dart';
import '../../../../../../../../../core/widgets/custom_text_field.dart';

class ApplicationReport extends StatelessWidget {
  const ApplicationReport({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AppReportBloc, AppReportState>(
      listener: (context, state) {
        if (state is AppReportSuccess) {
          context.getSnackBar(
            snackText: Strings.youAddedFeedbackToThApplication,
            isError: false,
          );
          MagicRouter.goBack();
        } else if (state is AppReportLoading) {
          const LoadingCircle();
        }
      },
      builder: (context, state) {
        return CustomScaffold(
            isFullScreen: true,
            child: Column(
              children: [
                const CustomAppBar(
                  title: Strings.appReport,
                ),
                const SizedBox(
                  height: 40,
                ),
                CustomTextField(
                  controller:
                      AppReportBloc.get(context).reportMessageController,
                  hintText: Strings.desc,
                  maxLines: 5,
                  height: Dimensions(context: context).textFieldHeight * 3,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomButton(
                    onTap: () {
                      AppReportBloc.get(context).add(AppEvent());
                    },
                    text: Strings.send),
              ],
            ));
      },
    );
  }
}
