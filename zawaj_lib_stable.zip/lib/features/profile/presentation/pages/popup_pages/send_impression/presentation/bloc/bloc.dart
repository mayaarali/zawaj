import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_impression/data/model/model.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_impression/domin/repository.dart';

class AppFeedbackCubit extends Cubit<FeedbackState> {
  final AppFeedbackRepositoryImpl repository;

  AppFeedbackCubit(this.repository) : super(FeedbackInitial());

  void sendFeedback(AppFeedback feedback) async {
    emit(FeedbackLoading());
    try {
      await repository.sendFeedback(feedback);

      emit(FeedbackSent());
    } catch (e) {
      emit(FeedbackError(message: 'Failed to send feedback.'));
    }
  }
}

abstract class FeedbackEvent {}

class SendFeedback extends FeedbackEvent {
  final AppFeedback feedback;

  SendFeedback({required this.feedback});
}

abstract class FeedbackState {}

class FeedbackInitial extends FeedbackState {}

class FeedbackLoading extends FeedbackState {}

class FeedbackSent extends FeedbackState {}

class FeedbackError extends FeedbackState {
  final String message;

  FeedbackError({required this.message});
}
