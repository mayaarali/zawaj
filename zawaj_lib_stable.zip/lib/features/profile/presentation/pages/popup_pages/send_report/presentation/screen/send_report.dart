import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/extensions/snack_bar.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_report/presentation/bloc/send_report_bloc.dart';

import '../../../../../../../../core/constants/dimensions.dart';
import '../../../../../../../../core/constants/strings.dart';
import '../../../../../../../../core/widgets/custom_appbar.dart';
import '../../../../../../../../core/widgets/custom_button.dart';
import '../../../../../../../../core/widgets/custom_text_field.dart';

class SendReport extends StatelessWidget {
  final String userId;
  const SendReport({
    super.key,
    required this.userId,
  });

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SendReportBloc, SendReportState>(
      listener: (context, state) {
        if (state is SendReportSuccess) {
          context.getSnackBar(
            snackText: Strings.youAddedFeedbackToThApplication,
            isError: false,
          );
        }
      },
      builder: (context, state) {
        return CustomScaffold(
            isFullScreen: true,
            child: Column(
              children: [
                const CustomAppBar(
                  title: Strings.report_user,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  hintText: Strings.user_name,
                  controller: SendReportBloc.get(context).userController,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomTextField(
                  controller: SendReportBloc.get(context).reportController,
                  hintText: Strings.desc,
                  maxLines: 5,
                  height: Dimensions(context: context).textFieldHeight * 3,
                ),
                const SizedBox(
                  height: 20,
                ),
                CustomButton(
                    onTap: () {
                      SendReportBloc.get(context)
                          .add(SentEvent(userId: userId));
                    },
                    text: Strings.send),
              ],
            ));
      },
    );
  }
}
/*
 leading: Container(
                color: Colors.amber,
                child: InkWell(
                  onTap: () {
                    MagicRouter.navigateTo(
                        SendReport(userId: homeModel.id.toString()));
                  },
                  child: const Padding(
                      padding: EdgeInsets.all(15),
                      child: Icon(
                          color: ColorManager.primaryColor,
                          size: 30,
                          Icons.more_horiz_outlined)),
*/