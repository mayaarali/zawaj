import 'package:bubble/bubble.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/helper/cache_helper.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/add_image_box.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/loading_circle.dart';
import 'package:zawaj/features/authentication/presentation/pages/login_signup/login_page.dart';
import 'package:zawaj/features/payment/presentation/pages/choose_bundle_screen.dart';
import 'package:zawaj/features/profile/data/models/profile_model.dart';
import 'package:zawaj/features/profile/presentation/bloc/profile_bloc.dart';
import 'package:zawaj/features/profile/presentation/bloc/states.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/application_report/presentation/application_report_screen.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/send_impression/presentation/screen/send_impression.dart';
import 'package:zawaj/features/profile/presentation/pages/popup_pages/settings/presentation/screen/setting.dart';
import 'package:zawaj/features/profile/presentation/pages/setup_data/my_data_setup.dart';
import 'package:zawaj/features/profile/presentation/pages/setup_data/my_partner_data.dart';
import 'package:zawaj/features/profile/presentation/pages/verification/verify_account_screen.dart';

import 'edit_profile/about_me/presentation/screen/about_me.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isShow = false;
  bool _isShowOthers = false;

  void showOtherEditsPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return const OtherEditsPopUp();
      },
    );
  }

  @override
  void initState() {
    ProfileBloc.get(context).getMyProfile();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _isShowOthers = false;
        });
      },
      child: BlocConsumer<ProfileBloc, ProfileStates>(
          listener: (BuildContext context, ProfileStates state) {},
          builder: (BuildContext context, ProfileStates state) {
            print(ProfileBloc.get(context).profileData);
            //  print(ProfileBloc.get(context).profileData!.verificationStatus);
            return CustomScaffold(
                isFullScreen: true,
                child: Stack(
                  alignment: AlignmentDirectional.bottomEnd,
                  children: [
                    SizedBox(
                      height: context.height,
                      width: context.width,
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              //   CustomAppBar(title: "",leading: Image.asset(ImageManager.setting),),
                              const SizedBox(
                                height: 10,
                              ),
                              Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Column(
                                        children: [
                                          ProfileBloc.get(context).profileData == null ||
                                                  ProfileBloc.get(context)
                                                      .profileData!
                                                      .images!
                                                      .isEmpty
                                              ? AddImageBox(
                                                  context.height * 0.2,
                                                  context.height * 0.2,
                                                  null,
                                                  () {},
                                                  () {})
                                              : ClipRRect(
                                                  borderRadius: BorderRadius.circular(
                                                      Dimensions.buttonRadius),
                                                  child: Image.network(
                                                      EndPoints.BASE_URL_image +
                                                          ProfileBloc.get(context)
                                                              .profileData!
                                                              .images![0],
                                                      height:
                                                          context.height * 0.2,
                                                      width:
                                                          context.height * 0.2,
                                                      fit: BoxFit.cover, errorBuilder:
                                                          (context, error, stackTrace) {
                                                    return const Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Center(
                                                            child: Icon(
                                                                Icons.error)),
                                                      ],
                                                    );
                                                  }, frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                                                    return child;
                                                  }, loadingBuilder: (context, child, loadingProgress) {
                                                    if (loadingProgress ==
                                                        null) {
                                                      return child;
                                                    } else {
                                                      return const Center(
                                                        child: LoadingCircle(),
                                                      );
                                                    }
                                                  })),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          ////////////////////////////VERIFIVATION ROW///////////////////////////
                                          ///

                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Builder(
                                                builder:
                                                    (BuildContext context) {
                                                  final ProfileData?
                                                      profileData =
                                                      ProfileBloc.get(context)
                                                          .profileData;
                                                  final String?
                                                      verificationStatus =
                                                      profileData
                                                          ?.verificationStatus;

                                                  if (verificationStatus ==
                                                      null) {
                                                    return IconButton(
                                                      color: Colors.grey,
                                                      onPressed: () {
                                                        setState(() {
                                                          _isShow = !_isShow;
                                                        });
                                                      },
                                                      icon: Icon(
                                                        Icons
                                                            .check_circle_outline,
                                                      ),
                                                    );
                                                  } else if (verificationStatus ==
                                                      'Accepted') {
                                                    return IconButton(
                                                      color: Colors.green,
                                                      onPressed: () {
                                                        setState(() {
                                                          _isShow = false;
                                                        });
                                                      },
                                                      icon: Icon(
                                                        Icons
                                                            .check_circle_outline,
                                                      ),
                                                    );
                                                  } else if (verificationStatus ==
                                                      'Pending') {
                                                    return IconButton(
                                                      color: Colors.grey,
                                                      icon: Icon(
                                                        Icons
                                                            .check_circle_outline,
                                                      ),
                                                      onPressed: () {},
                                                    );
                                                  } else {
                                                    return IconButton(
                                                      color: Colors.grey,
                                                      onPressed: () {
                                                        setState(() {
                                                          _isShow = !_isShow;
                                                        });
                                                      },
                                                      icon: Icon(
                                                        Icons
                                                            .check_circle_outline,
                                                      ),
                                                    );
                                                  }
                                                },
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              CustomText(
                                                text: ProfileBloc.get(context)
                                                            .profileData ==
                                                        null
                                                    ? 'Name'
                                                    : ProfileBloc.get(context)
                                                            .profileData!
                                                            .name ??
                                                        'Name',
                                                fontSize: Dimensions.largeFont,
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  //popup checkaccount

                                  Visibility(
                                    visible: _isShow,
                                    child: Positioned(
                                      right: context.width * -0.02,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 22),
                                        child: InkWell(
                                          onTap: () {
                                            MagicRouter.navigateTo(
                                                const VerifyScreen());
                                          },
                                          child: Bubble(
                                            margin: const BubbleEdges.only(
                                                bottom: 10),
                                            nip: BubbleNip.leftBottom,
                                            color:
                                                ColorManager.secondaryPinkColor,
                                            child: const CustomText(
                                              text: Strings.check_account,
                                              align: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(
                                height: 20,
                              ),

                              const SizedBox(
                                height: 30,
                              ),

                              buildRow(Strings.my_personal_data, () {
                                MagicRouter.navigateTo(const MyProfileData());
                              }),
                              //buildRow(Strings.image, () {}),
                              buildRow(Strings.who_i, () {
                                MagicRouter.navigateTo(AboutMe());
                              }),

                              const Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    text: Strings.mainly,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 20,
                                    align: TextAlign.start,
                                  ),
                                  CustomText(
                                    text: Strings.not_mainly,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 20,
                                    align: TextAlign.start,
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              CustomButton(
                                  onTap: () {
                                    MagicRouter.navigateTo(ChooseBundle());
                                  },
                                  text: Strings.get_best),
                              const SizedBox(
                                height: 10,
                              ),
                              CustomButton(
                                onTap: () {
                                  MagicRouter.navigateTo(const MyPartnerData());
                                },
                                text: Strings.partner,
                                txtColor: ColorManager.primaryColor,
                                borderColor: ColorManager.primaryColor,
                                color: Colors.white,
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              const CustomText(
                                text: Strings.delete_account,
                                textDecoration: TextDecoration.underline,
                                fontWeight: FontWeight.normal,
                              ),
                              const SizedBox(
                                height: 7,
                              ),
                              InkWell(
                                onTap: () {
                                  setState(
                                    () {
                                      _isShowOthers = !_isShowOthers;
                                    },
                                  );
                                },
                                child: const CustomText(
                                  text: Strings.other,
                                  textDecoration: TextDecoration.underline,
                                  fontWeight: FontWeight.normal,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: _isShowOthers,
                      child: const SizedBox(
                        width: 250,
                        child: OtherEditsPopUp(),
                      ),
                    )
                  ],
                ));
          }),
    );
  }

  Widget buildRow(text, onTap) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                  child: CustomText(
                text: text,
                fontWeight: FontWeight.normal,
                fontSize: Dimensions.normalFont,
                align: TextAlign.start,
              )),
              const Icon(
                Icons.arrow_forward_ios,
                color: ColorManager.primaryColor,
              )
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 12),
          child: Divider(
            color: ColorManager.secondaryPinkColor,
            thickness: 2,
          ),
        )
      ],
    );
  }
}

class OtherEditsPopUp extends StatelessWidget {
  const OtherEditsPopUp({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      //width: 50,
      // height: context.height * 0.5,
      child: Card(
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadiusDirectional.only(
                topStart: Radius.circular(Dimensions.buttonRadius),
                topEnd: Radius.circular(Dimensions.buttonRadius),
                bottomStart: Radius.circular(Dimensions.buttonRadius))),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 10,
              ),
              InkWell(
                  onTap: () {
                    MagicRouter.navigateTo(const ApplicationReport());
                  },
                  child: const CustomText(
                    text: Strings.report,
                  )),
              Divider(
                color: ColorManager.hintTextColor.withOpacity(0.5),
              ),
              const SizedBox(
                height: 10,
              ),
              InkWell(
                  onTap: () {
                    MagicRouter.navigateTo(SendImpression());
                  },
                  child: const CustomText(text: Strings.review)),
              Divider(
                color: ColorManager.hintTextColor.withOpacity(0.5),
              ),
              const SizedBox(
                height: 10,
              ),
              InkWell(
                  onTap: () {
                    MagicRouter.navigateTo(const Setting());
                  },
                  child: const CustomText(text: Strings.setting)),
              Divider(
                color: ColorManager.hintTextColor.withOpacity(0.5),
              ),
              const SizedBox(
                height: 10,
              ),
              InkWell(
                  onTap: () async {
                    //  SystemNavigator.pop();

                    await FirebaseAuth.instance.signOut();
                    GoogleSignIn googleSignIn = GoogleSignIn();
                    googleSignIn.disconnect();
                    await CacheHelper.removeData(key: Strings.token);
                    await CacheHelper.removeData(key: Strings.hasSetup);
                    await CacheHelper.removeData(key: Strings.hasRequired);
                    // await CacheHelper.removeAllData();
                    MagicRouter.navigateAndPopAll(const LoginPage());
                  },
                  child: const CustomText(text: Strings.exit)),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
