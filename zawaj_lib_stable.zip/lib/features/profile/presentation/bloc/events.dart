abstract class ProfileEvent {}

class DeleteProfileEvent extends ProfileEvent {}
