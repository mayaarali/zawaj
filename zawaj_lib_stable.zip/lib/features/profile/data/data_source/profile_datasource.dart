import '../../../../core/constants/end_points.dart';
import '../../../../core/helper/dio_helper.dart';

class ProfileDataSourceImp {
  @override
  DioHelper apiClientHelper;
  ProfileDataSourceImp({required this.apiClientHelper});

  Future getProfile() {
    return apiClientHelper
        .getData(url: EndPoints.profile_data, query: {"lang": "en"});
  }

  Future getProfilePartner() {
    return apiClientHelper
        .getData(url: EndPoints.profile_partner, query: {"lang": "en"});
  }

  Future deleteProfile() {
    return apiClientHelper.putData(
      url: EndPoints.deleteAccount,
    );
  }
}



























    /*required String gender,
    required String searchGender,
    required String name,
    required String birthYear,
    required String cityId,
    required String areaId,
    required String maritalStatus,
    required String minAge,
    required String maxAge,
    required String height,
    required String weight,
    required String isSmoking,*/