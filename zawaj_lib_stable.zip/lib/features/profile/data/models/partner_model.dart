

class PartnerData {
  int? minAge;
  int? maxAge;
  String? gender;
  double? height;
  double? weight;
  bool? isSmoking;
  List<Parameter>? parameters;

  PartnerData({
    this.minAge,
    this.maxAge,
    this.gender,
    this.height,
    this.weight,
    this.isSmoking,
    this.parameters,
  });

  factory PartnerData.fromJson(Map<String, dynamic> json) => PartnerData(
    minAge: json["minAge"],
    maxAge: json["maxAge"],
    gender: json["gender"],
    height: json["height"]?.toDouble(),
    weight: json["weight"]?.toDouble(),
    isSmoking: json["isSmoking"],
    parameters: json["parameters"] == null ? [] : List<Parameter>.from(json["parameters"]!.map((x) => Parameter.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "minAge": minAge,
    "maxAge": maxAge,
    "gender": gender,
    "height": height,
    "weight": weight,
    "isSmoking": isSmoking,
    "parameters": parameters == null ? [] : List<dynamic>.from(parameters!.map((x) => x.toJson())),
  };
}

class Parameter {
  String? parameterName;
  int? parameterType;
  int? valueId,parameterId;
  String? valueName;

  Parameter({
    this.parameterName,
    this.parameterType,
    this.valueId,
    this.valueName,
    this.parameterId
  });

  factory Parameter.fromJson(Map<String, dynamic> json) => Parameter(
    parameterName: json["parameterName"],
    parameterType: json["parameterType"],
    parameterId:json['parameterId'],
    valueId: json["valueId"],
    valueName: json["valueName"],
  );

  Map<String, dynamic> toJson() => {
    "parameterName": parameterName,
    "parameterType": parameterType,
    "valueId": valueId,
    "valueName": valueName,
  };
}
