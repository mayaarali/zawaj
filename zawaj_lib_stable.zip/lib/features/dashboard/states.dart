abstract class DashboardState{
}

class SelectIndex extends DashboardState{}
class InitDashboardState extends DashboardState{}


