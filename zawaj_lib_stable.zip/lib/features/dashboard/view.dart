import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/features/dashboard/cubit.dart';
import 'package:zawaj/features/dashboard/states.dart';

class DashBoardScreen extends StatelessWidget {
  final int initialIndex;
  const DashBoardScreen({super.key, required this.initialIndex});

  @override
  Widget build(BuildContext context) {
    DashBoardCubit cubit = DashBoardCubit.get(context);
    cubit.changeIndex(initialIndex); // Set the initial index
    return BlocConsumer<DashBoardCubit, DashboardState>(
      listener: (context, state) {},
      builder: (context, state) => CustomScaffold(
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: BottomNavigationBar(
              elevation: 10,
              currentIndex: cubit.currentIndex,
              items: [
                BottomNavigationBarItem(
                    icon: SvgPicture.asset(cubit.currentIndex == 0
                        ? ImageManager.heart_colored
                        : ImageManager.heart),
                    label: ''),
                BottomNavigationBarItem(
                    icon: SvgPicture.asset(cubit.currentIndex == 1
                        ? ImageManager.chat_colored
                        : ImageManager.chat),
                    label: ''),
                BottomNavigationBarItem(
                    icon: SvgPicture.asset(cubit.currentIndex == 2
                        ? ImageManager.home_colored
                        : ImageManager.home),
                    label: ''),
                BottomNavigationBarItem(
                    icon: SvgPicture.asset(ImageManager.notification,
                        color: cubit.currentIndex == 3
                            ? ColorManager.primaryColor
                            : ColorManager.hintTextColor),
                    label: ''),
                BottomNavigationBarItem(
                  icon: Icon(
                      cubit.currentIndex == 4
                          ? Icons.person
                          : Icons.person_outline_rounded,
                      color: cubit.currentIndex == 4
                          ? ColorManager.primaryColor
                          : ColorManager.hintTextColor),
                  label: '',
                ),
              ],
              onTap: (i) {
                cubit.changeIndex(i);
              },
            ),
          ),
          child: cubit.pages[cubit.currentIndex]),
    );
  }
}
