import 'dart:convert';

String chatModelToJson(List<ChatModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ChatModel {
  String? receiverId;
  String? message;

  ChatModel({this.receiverId, this.message});

  Map<String, dynamic> toJson() => {
        "receiverId": receiverId,
        "message": message,
      };
}
