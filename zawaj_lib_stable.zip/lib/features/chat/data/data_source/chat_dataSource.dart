import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/helper/dio_helper.dart';

class ChatDataSourceImp {
  @override
  DioHelper apiClientHelper;
  ChatDataSourceImp({required this.apiClientHelper});

  Future sendMessage({required String receiverId, required String message}) {
    return apiClientHelper.postData(
      url: EndPoints.sendMessage,
      query: {
        "receiverId": receiverId,
        "message": message,
      },
    );
  }
}
