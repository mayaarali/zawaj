import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/helper/api_error_handler.dart';
import 'package:zawaj/core/network/network_info.dart';
import 'package:zawaj/features/chat/data/data_source/chat_dataSource.dart';

class ChatRepositoryImp {
  ChatDataSourceImp chatDataSourceImp;
  NetworkInfo networkInfo;
  ChatRepositoryImp(
      {required this.chatDataSourceImp, required this.networkInfo});
  Future<Either<String, String>> sendMessage({
    required String receiverId,
    required String message,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        Response response = await chatDataSourceImp.sendMessage(
          receiverId: receiverId,
          message: message,
        );

        if (response.statusCode == 200) {
          //   response.data!.forEach((e) {});

          return const Right(Strings.login_success);
        } else {
          return Left(ApiExceptionHandler.getMessage(response));
        }
      } on DioException catch (error) {
        return Left(ApiExceptionHandler.getMessage(error));
      }
    } else {
      return const Left(Strings.nointernet);
    }
  }
}
