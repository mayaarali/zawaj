import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_bubbles/bubbles/bubble_special_two.dart';
import 'package:flutter/material.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/strings.dart';

class RecieverBubble extends StatelessWidget {
  final String message;
  final String imagePath;
  const RecieverBubble(
      {super.key, required this.message, required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        children: [
          ClipOval(
            child: CachedNetworkImage(
              imageUrl: 'imagePath',
              height: 30,
              width: 30,
              placeholder: (context, url) =>
                  const Center(child: CircularProgressIndicator()),
              errorWidget: (context, url, error) => const Icon(Icons.error),
            ),
          ),
          BubbleSpecialTwo(
              isSender: false,
              text: message,
              color: ColorManager.fadePinkColor,
              textStyle: const TextStyle(
                fontSize: Dimensions.normalFont,
                color: ColorManager.primaryTextColor,
              )),
        ],
      ),
    );
  }
}
