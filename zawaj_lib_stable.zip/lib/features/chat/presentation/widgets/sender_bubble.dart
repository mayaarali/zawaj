import 'package:chat_bubbles/bubbles/bubble_special_two.dart';
import 'package:flutter/material.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/strings.dart';

class SenderBubble extends StatelessWidget {
  final String message;
  const SenderBubble({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return BubbleSpecialTwo(
        text: message,
        color: ColorManager.primaryTextColor,
        textStyle: TextStyle(
          fontSize: Dimensions.normalFont,
          color: ColorManager.whiteTextColor,
        ));
  }
}
