part of 'chat_bloc.dart';

abstract class ChatEvent {}

class SendMessageEvent extends ChatEvent {
  String receiverId;
  String message;
  SendMessageEvent({required this.receiverId, required this.message});
}
