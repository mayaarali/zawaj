import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/chat/data/repos/chat_repository.dart';

part 'chat_event.dart';
part 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  static ChatBloc get(context) => BlocProvider.of(context);
  ChatRepositoryImp chatRepositoryImp;
  ChatBloc({required this.chatRepositoryImp}) : super(ChatInitial()) {
    on<SendMessageEvent>((event, emit) async {
      emit(ChatLoading());

      var response = await chatRepositoryImp.sendMessage(
        receiverId: event.receiverId,
        message: event.message,
      );
      response.fold((failure) {
        emit(ChatFailure(message: failure));
      }, (message) {
        emit(ChatSuccess(message: message));
      });
    });
  }
}
