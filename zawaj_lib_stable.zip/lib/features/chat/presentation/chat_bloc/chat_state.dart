part of 'chat_bloc.dart';

abstract class ChatState {}

final class ChatInitial extends ChatState {}

final class ChatLoading extends ChatState {}

final class ChatSuccess extends ChatState {
  final String message;
  ChatSuccess({required this.message});
}

final class ChatFailure extends ChatState {
  final String message;
  ChatFailure({required this.message});
}
