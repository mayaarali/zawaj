import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:giphy_get/giphy_get.dart';
import 'package:signalr_core/signalr_core.dart';
import 'package:zawaj/core/camera/view/pages/camera_page.dart';
import 'package:zawaj/core/constants/end_points.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/features/chat/presentation/chat_message_cubit/chat_messages_cubit.dart';
import 'package:zawaj/features/chat/presentation/chat_message_cubit/chat_messages_states.dart';
import 'package:zawaj/features/chat/presentation/widgets/reciever_bubble.dart';
import 'package:zawaj/features/chat/presentation/widgets/sender_bubble.dart';
import 'package:zawaj/features/profile/presentation/bloc/profile_bloc.dart';

class ChatScreen extends StatefulWidget {
  final String receiverId;
  final String receiverProdileImage;

  const ChatScreen({
    super.key,
    required this.receiverId,
    required this.receiverProdileImage,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final List<String> _messages = [];
  final ScrollController _scrollController = ScrollController();

  late HubConnection _hubConnection;
  String _connectionId = '';

  @override
  void initState() {
    super.initState();
    log('user id 1 ${ProfileBloc.get(context).profileData!.id}');
    log('user id 2 ${widget.receiverId}');
    _initSignalR();
    //context.read<ChatMessagesCubit>().getChatMessagesData(widget.receiverId);
  }

  void _initSignalR() async {
    _hubConnection = HubConnectionBuilder().withUrl(
        "${EndPoints.signalRHub}${ProfileBloc.get(context).profileData!.id}",
        HttpConnectionOptions(
      logging: (level, message) {
        log('iam in loggging in');
        log(message);
        log(level.toString());

        context
            .read<ChatMessagesCubit>()
            .getChatMessagesData(widget.receiverId);
      },
    )).build();

    _hubConnection.on("ReceiveMessage", (List<dynamic>? args) {
      if (args != null && args.isNotEmpty) {
        setState(() {
          _messages.add(args.last.toString());
        });
      }
    });
    try {
      await _hubConnection.start();
      _connectionId = _hubConnection.connectionId!;
    } catch (e) {
      log("Error starting connection: $e");
    }
  }

  void _sendMessage() {
    String message = _textController.text.trim();
    if (message.isNotEmpty) {
      _hubConnection.invoke(
        args: [
          ProfileBloc.get(context).profileData!.id,
          widget.receiverId,
          message,
        ],
        "SendMessage",
      );
      log('this is message $message');
      _initSignalR();

      _textController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<ChatMessagesCubit, ChatMessagesState>(
        builder: (context, state) {
          if (state is ChatMessagesLoadingState) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is ChatMessagesErrorState) {
            log('Error: ${state.error}');
            return Stack(
              children: [
                const Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: CustomAppBar(
                        isHeartTitle: true,
                        isBack: true,
                        isSettingIcon: true,
                        title: 'Chat',
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [],
                        ),
                      ),
                    ),
                  ],
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    margin: const EdgeInsets.all(10),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    height: 60,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(35.0),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          blurRadius: 8,
                          spreadRadius: 8,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        InkWell(
                          child: SvgPicture.asset(ImageManager.videoLogo),
                          onTap: () {
                            MagicRouter.navigateAndReplacement(
                                const CameraPage());
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8, right: 8),
                          child: InkWell(
                            child: SvgPicture.asset(ImageManager.gifLogo),
                            onTap: () async {
                              GiphyGif? gif = await GiphyGet.getGif(
                                context: context,
                                apiKey: EndPoints.gifAPIKEY,
                                lang: GiphyLanguage.english,
                                randomID: "abcd",
                                tabColor: Colors.teal,
                                debounceTimeInMilliseconds: 350,
                              );
                            },
                          ),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _textController,
                            decoration: const InputDecoration(
                              hintText: 'اكتب رسالة ...',
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                        InkWell(
                          child: SvgPicture.asset(
                            ImageManager.sendIcon,
                            width: 40,
                            height: 40,
                          ),
                          onTap: () => _sendMessage(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          } else if (state is ChatMessagesLoadedState) {
            return Column(
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: CustomAppBar(
                    isHeartTitle: true,
                    isBack: true,
                    isSettingIcon: true,
                    title: 'Chat',
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    reverse: true,
                    child: ListView.builder(
                      reverse: false,
                      shrinkWrap: true,
                      controller: _scrollController,
                      itemCount: state.chatData.messages.length,
                      itemBuilder: (context, index) {
                        final currentMessage = state.chatData.messages[index];
                        final previousMessage = index > 0
                            ? state.chatData.messages[index - 1]
                            : null;

                        final bool isFirstMessageOfDay = previousMessage ==
                                null ||
                            !isSameDay(
                                currentMessage.sentAt, previousMessage.sentAt);

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            if (isFirstMessageOfDay)
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16.0, vertical: 8.0),
                                child: Text(
                                  DateFormat(
                                          'dd MMM, yyyy الساعة hh:mm a', 'ar')
                                      .format(currentMessage.sentAt),
                                  style: const TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15.0,
                                  ),
                                ),
                              ),
                            ListTile(
                              title: widget.receiverId !=
                                      currentMessage.recipientId
                                  ? RecieverBubble(
                                      message: currentMessage.content,
                                      imagePath: widget.receiverProdileImage,
                                    )
                                  : SenderBubble(
                                      message: currentMessage.content,
                                    ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.all(10),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  height: 60,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(35.0),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            blurRadius: 8,
                            spreadRadius: 8)
                      ]),
                  child: Row(
                    children: [
                      InkWell(
                        child: SvgPicture.asset(ImageManager.videoLogo),
                        onTap: () {
                          MagicRouter.navigateAndReplacement(
                              const CameraPage());
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8, right: 8),
                        child: InkWell(
                          child: SvgPicture.asset(ImageManager.gifLogo),
                          onTap: () async {
                            GiphyGif? gif = await GiphyGet.getGif(
                              context: context,
                              apiKey: EndPoints.gifAPIKEY,
                              lang: GiphyLanguage.english,
                              randomID: "abcd",
                              tabColor: Colors.teal,
                              debounceTimeInMilliseconds: 350,
                            );
                          },
                        ),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _textController,
                          decoration: const InputDecoration(
                            hintText: 'اكتب رسالة ...',
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      InkWell(
                        child: SvgPicture.asset(ImageManager.sendIcon,
                            width: 40, height: 40),
                        onTap: () => _sendMessage(),
                      ),
                    ],
                  ),
                ),
              ],
            );
          } else {
            return const Center(child: Text('Unknown state'));
          }
        },
      ),
    );
  }

  @override
  void dispose() {
    _hubConnection.stop();
    _scrollController.dispose();

    super.dispose();
  }

  bool isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }
}
