import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/features/chat/domain/get_chat_messages_usecase.dart';
import 'package:zawaj/features/chat/presentation/chat_message_cubit/chat_messages_states.dart';

class ChatMessagesCubit extends Cubit<ChatMessagesState> {
  final GetChatMessagesDataUseCase _getChatMessagesDataUseCase;

  ChatMessagesCubit(this._getChatMessagesDataUseCase)
      : super(ChatMessagesLoadingState());

  Future<void> getChatMessagesData(String user2Id) async {
    try {
      final chatData = await _getChatMessagesDataUseCase(user2Id);
      emit(ChatMessagesLoadedState(chatData));
    } catch (e) {
      emit(ChatMessagesErrorState('Failed to fetch chat data: $e'));
    }
  }
}
