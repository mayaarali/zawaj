import 'package:flutter/material.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/custom_text_field.dart';

import '../core/constants/color_manager.dart';
import '../core/router/routes.dart';

class ChatScreenList extends StatelessWidget {
  const ChatScreenList({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        isFullScreen: true,
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 20,
              ),
              const Row(
                children: [
                  Expanded(
                      child: CustomTextField(
                    hintText: 'search',
                    height: 60,
                  )),
                  SizedBox(
                    width: 30,
                  ),
                  // InkWell(
                  //     onTap: () {
                  //       MagicRouter.goBack();
                  //     },
                  //     child: const Icon(
                  //       Icons.arrow_forward,
                  //       color: ColorManager.hintTextColor,
                  //     )),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const CustomText(
                    text: 'مراسلات',
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Container(
                    height: 25,
                    width: 25,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: ColorManager.secondaryPinkColor),
                    child: const Padding(
                      padding: EdgeInsets.all(2),
                      child: Center(
                          child: CustomText(
                        text: '2',
                      )),
                    ),
                  )
                ],
              ),
              const SizedBox(
                height: 40,
              ),
              const Item(),
              const Item(),
              const Item(),
            ],
          ),
        ));
  }
}

class Item extends StatelessWidget {
  const Item({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        //   MagicRouter.navigateTo( ChatScreen(), );
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              'assets/images/User pic.png',
              height: 100,
              width: 100,
            ),
            const SizedBox(
              width: 10,
            ),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomText(
                  text: 'عباد، 22',
                  align: TextAlign.center,
                ),
                CustomText(
                  text: 'مرحبًا كيف حالك اليوم؟',
                  align: TextAlign.center,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
