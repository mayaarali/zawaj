import 'package:flutter/material.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/extensions/colored_print.dart';
import 'package:zawaj/core/extensions/sizes.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/logo_image.dart';
import 'package:zawaj/features/authentication/presentation/pages/login_signup/login_page.dart';
import 'package:zawaj/features/dashboard/view.dart';
import 'package:zawaj/features/setup_account/presentation/pages/gender_screen.dart';
import 'package:zawaj/features/setup_account/presentation/pages/set_partenal_data.dart';
import '../../core/constants/strings.dart';
import '../../core/helper/cache_helper.dart';
import '../../core/router/routes.dart';
import '../onBoarding/view.dart';

class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  @override
  void initState() {
    super.initState();
    String? token = CacheHelper.getData(key: Strings.token);
    bool isFirst = CacheHelper.getData(key: Strings.isFirst) ?? true;
    bool hasSetup = CacheHelper.getData(key: Strings.hasSetup) ?? false;
    bool hasRequired = CacheHelper.getData(key: Strings.hasRequired) ?? false;

    context.printGreen('isFirst=================>$isFirst');
    context.printGreen('hasSetup=================>$hasSetup');
    context.printGreen('hasRequired=================>$hasRequired');
    context.printGreen('token=================>$token');

    Future.delayed(const Duration(seconds: 2), () {
      // MagicRouter.navigateAndReplacement(const LoginPage());

      isFirst == true
          ? MagicRouter.navigateAndReplacement(const OnBoarding())
          : token == null
              ? MagicRouter.navigateAndReplacement(const LoginPage())
              : hasRequired
                  ? MagicRouter.navigateAndReplacement(const DashBoardScreen(
                      initialIndex: 2,
                    ))
                  : hasSetup
                      ? MagicRouter.navigateAndReplacement(SetPartnerData(
                          isUpdated: false,
                        ))
                      : MagicRouter.navigateAndReplacement(
                          const GenderScreen());

      //   MagicRouter.navigateAndReplacement(const DashBoardScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
        child: Container(
      height: context.height,
      width: context.width,
      decoration: BoxDecoration(
          gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        // stops: [0.01, 0.3, 0.4],

        colors: [
          ColorManager.splashTopColor,
          Colors.black,
          Colors.black,
          ColorManager.splashBottomColor,
        ],
      )),
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        // crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [LogoImage()],
      ),
    ));
  }
}
