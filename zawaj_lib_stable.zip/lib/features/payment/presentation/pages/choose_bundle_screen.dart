import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/build_dialog.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/features/payment/presentation/pages/payment_possibilities.dart';

class ChooseBundle extends StatelessWidget {
  const ChooseBundle({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isFullScreen: true,
      child: SingleChildScrollView(
        child: Column(
          children: [
            const CustomAppBar(
              isLogoTitle: true,
            ),
            const SizedBox(
              height: 50,
            ),
            const CustomText(
              text: Strings.choose_bundle,
              fontSize: Dimensions.largeFont,
            ),
            const SizedBox(
              height: 30,
            ),
            Image.asset(ImageManager.heart_message),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 30),
              child: CustomText(
                text: Strings.golden_bundle,
                fontSize: Dimensions.normalFont,
              ),
            ),
            CustomButton(
                onTap: () {
                  buildDialog(
                    isIcon: true,
                    isIconImage: SvgPicture.asset(ImageManager.check_mark),
                    optionalButtonTitle: Strings.mayBeLater,
                    onTapOptional: () {},
                    context: context,
                    onTapEnter: () {
                      MagicRouter.navigateTo(PayementPossibility());
                    },
                    buttonTitle: Strings.complete,
                    title: Strings.payment,
                    desc: Strings.add_payment_method,
                  );
                },
                text: Strings.golden_bundle_button),
            const SizedBox(
              height: 5,
            ),
            TextButton(
                onPressed: () {},
                child: const Text(
                  Strings.cancelpills,
                  style: TextStyle(
                    color: ColorManager.hintTextColor,
                  ),
                )),
            const CustomText(
              align: TextAlign.start,
              text: Strings.free_bundle_instructions,
              fontSize: Dimensions.normalFont,
            )
          ],
        ),
      ),
    );
  }
}
