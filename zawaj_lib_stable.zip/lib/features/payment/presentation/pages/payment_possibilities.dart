import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/svg.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/dimensions.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/validator/validator.dart';
import 'package:zawaj/core/widgets/custom_appbar.dart';
import 'package:zawaj/core/widgets/custom_button.dart';
import 'package:zawaj/core/widgets/custom_scaffold.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/core/widgets/custom_text_field.dart';
import 'package:zawaj/features/notification/presentation/screens/likes_notification_page.dart';

class PayementPossibility extends StatefulWidget {
  const PayementPossibility({super.key});

  @override
  State<PayementPossibility> createState() => _PayementPossibilityState();
}

class _PayementPossibilityState extends State<PayementPossibility> {
  bool isSelected1 = true;
  bool isSelected2 = false;
  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      isFullScreen: true,
      child: SingleChildScrollView(
        child: Column(
          children: [
            const CustomAppBar(
              isBack: true,
              title: Strings.payementPossibility,
            ),
            Container(
              width: 335,
              height: 170,
              decoration: BoxDecoration(
                color: ColorManager.pinkColor,
                borderRadius: BorderRadius.circular(30),
              ),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              isSelected1 = !isSelected1;
                              isSelected2 = false;
                            });
                          },
                          child: Row(
                            children: [
                              Container(
                                width: 18,
                                height: 18,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: ColorManager.hintTextColor,
                                    width: 1.0,
                                  ),
                                  color: isSelected1
                                      ? ColorManager.primaryTextColor
                                      : ColorManager.whiteTextColor,
                                ),
                              ),
                              const SizedBox(width: 10),
                              const CustomText(
                                text: Strings.bankTransfer,
                                fontWeight: FontWeight.w500,
                              ),
                            ],
                          ),
                        ),

                        /*
                        Radio(
                            visualDensity: const VisualDensity(
                                // horizontal: VisualDensity.minimumDensity,
                                //  vertical: VisualDensity.minimumDensity
                                ),
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                            fillColor: MaterialStateProperty.all(
                                ColorManager.whiteTextColor),
                            overlayColor: MaterialStateProperty.all(
                                ColorManager.primaryColor),
                            activeColor: ColorManager.primaryTextColor,
                            value: 1,
                            groupValue: '',
                            onChanged: (value) {}),
                            */
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10, top: 10),
                      child: Container(
                          child: SvgPicture.asset(ImageManager.paymentMethods)),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              isSelected1 = false;
                              isSelected2 = !isSelected2;
                            });
                          },
                          child: Row(
                            children: [
                              Container(
                                width: 18,
                                height: 18,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: ColorManager.hintTextColor,
                                    width: 1.0,
                                  ),
                                  color: isSelected2
                                      ? ColorManager.primaryTextColor
                                      : ColorManager.whiteTextColor,
                                ),
                              ),
                              const SizedBox(width: 10),
                              const CustomText(
                                text: Strings.payPall,
                                fontWeight: FontWeight.w500,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10, top: 5),
                      child: Container(

                          ///   color: Colors.amber,
                          child: Image.asset(
                        ImageManager.payPallPng,
                        fit: BoxFit.contain,
                      )),
                    ),
                    /*   Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Container(
                          child: SvgPicture.asset(ImageManager.payPallMethod)),
                    ),
                    */
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            PayementExpandedPanel(
              expanded: //Text('iam expanded'),
                  const Column(
                children: [
                  ExpandableBody(),
                ],
              ),
              header: CustomText(
                  text: isSelected2 ? Strings.payPall : Strings.bankTransfer,
                  // Strings.payPall,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 20,
            ),

            //   Row(
            //     mainAxisAlignment: MainAxisAlignment.center,
            //     children: [
            //       TextButton(
            //           onPressed: () {},
            //           child: const CustomText(
            //             text: Strings.changeCountry,
            //             fontWeight: FontWeight.w600,
            //             textDecoration: TextDecoration.underline,
            //           )),
            //       const CustomText(
            //         text: "إستونيا",
            //         fontSize: 12,
            //       )
            //     ],
            //   ),
          ],
        ),
      ),
    );
  }
}

class PayementExpandedPanel extends StatelessWidget {
  const PayementExpandedPanel(
      {super.key, required this.header, required this.expanded});
  final Widget expanded;
  final Widget header;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: ExpandablePanel(
        theme: const ExpandableThemeData(
          iconColor: ColorManager.primaryColor,
          iconPlacement: ExpandablePanelIconPlacement.right,
        ),
        header: Padding(
          padding: const EdgeInsets.fromLTRB(
              8.0, 8.0, 8.0, 0.0), // Adjusted padding values
          child: Row(
            children: [
              header,
            ],
          ),
        ),
        collapsed: const SizedBox(),
        expanded: expanded,
      ),
    );
  }
}

class ExpandableBody extends StatelessWidget {
  const ExpandableBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Row(
        children: [
          const CustomText(
            text: Strings.payementDetails,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          Spacer(),
          SvgPicture.asset(
            ImageManager.lock,
            width: 20,
            height: 20,
            fit: BoxFit.scaleDown,
          ),
        ],
      ),
      SizedBox(
        height: 20,
      ),
      CustomTextField(
        hintText: Strings.cardNo,
        keyboardType: TextInputType.number,
        //  controller: AuthBloc.get(context).nameController,
        validate: (v) => Validator.validatePayementCard(v),
      ),
      const SizedBox(
        height: 10,
      ),
      CustomTextField(
        hintText: Strings.expiryDate,
        //  controller: AuthBloc.get(context).phoneController,
        validate: (v) => Validator.expiryCardDate(v),
        keyboardType: TextInputType.number,
      ),
      const SizedBox(
        height: 10,
      ),
      CustomTextField(
        hintText: Strings.payementPass,
        //   controller: AuthBloc.get(context).emailController,
        validate: (v) => Validator.validatePassword(v),
      ),
      const SizedBox(
        height: 10,
      ),
      CustomTextField(
        hintText: Strings.idNo,
        keyboardType: TextInputType.number,
        //  controller: AuthBloc.get(context).nameController,
        validate: (v) => Validator.validatePayementCard(v),
      ),
      const SizedBox(
        height: 10,
      ),
      const CustomText(
        align: TextAlign.right,
        text: Strings.payementInstructions,
        color: ColorManager.hintTextColor,
        fontSize: 11.5,
      ),
      const SizedBox(
        height: 40,
      ),
      CustomButton(
          onTap: () {
            MagicRouter.navigateTo(LikeNotificationPage());
          },
          text: Strings.payNow)
    ]);
  }
}
