enum MaritalState{
single,married,heDivorced,sheDivorced,divorcedWithChildren,divorcedWithNoChildren,widower,other
}