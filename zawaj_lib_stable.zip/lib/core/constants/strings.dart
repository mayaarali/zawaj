class Strings {
  static const String Data = "الاسم و العمر";
  static const String LOGIN_NOW = "سجّل للدّخول الآن!";
  static const String about_me = "عن نفسي";
  static const String accept_terms_conditions = "أوافق على الشروط والأحكام";
  static const String add_payment_method = "للمتابعة أضف طريقة الدفع";
  static const String add_photos = "أضف صورك";
  static const String birthyear = "سنه الولاده";
  static const String birthyear2 = "سنه الميلاد";
  static const String by_phone = "عن طريق الجوال";
  static const String cancelpills = "  إلغاء الفواتير المتكررة في أي وقت";
  static const String caracter_password =
      "يجب ان تحتوي كلمة المرور على : (8 أحرف أو أكثر)";

  static const String change_email = "تغيير البريد الإلكتروني";
  static const String check_account = "تحقق من حسابك";
  static const String check_email = "قم بالتحقق من بريدك الإلكتروني للمتابعة.";
  static const String check_your_email =
      "للمتابعة, يرجى التحقق من بريدك الالكتروني وفتح الرابط الذي تم ارساله اليك";

  static const String choose_bundle = " اختر الرزمة المناسبة لك";
  static const String complete = "اكمل";
  static const String complete_setup =
      "ملفك الشخصي قد اكتمل بنجاح، ويمكنك البدء في البحث عن شريك/ ة حياتك الآن.";

  static const String confirm = "تأكيد";
  static const String congrats = "تهانينا!";
  static const String continue_setup =
      "من اجل زيادة احتمالات عثورك على الشريك/ة المناسب/ة ، عليك تسجيل التفاصيل الآتية:";

  static const String continue_with_phone = "المتابعة باستخدام رقم الهاتف.";
  static const String create_account = "عن طريق إنشاء حساب مجاني.";
  static const String delete_account = "حذف الحساب";
  static const String desc = "وصف";
  static const String divorcedWithChildren = "منفصل مع اولاد";
  static const String divorcedWithNoChildren = "منفصل بدون اولاد";
  static const String dont_receive_code = "لم تتلق أي رمز؟ إعادة مرة أخرى";
  static const String email = "البريد الإلكتروني";
  static const String email_address = "عنوان البريد الإلكتروني";
  static const String email_sent = "تم إرسال البريد الإلكتروني.";
  static const String empty_notif = "حتى الآن لم يعجبك أحد. كن أول من يعجبه";
  static const String enter_email_send_link =
      "ادخل بريدك الإلكتروني وسنرسل اليك رابطًا لإعادة تعيين كلمة المرور.";

  static const String enter_otp = "ادخال رمز التحقق";
  static const String enter_otp_from_email =
      "ادخل رمز التحقق الذي تم ارساله الى بريدك الالكتروني";

  static const String enter_phone = "أدخل رقم هاتفك";
  static const String exit = "الخروج";
  static const String facebook_sign_in = "المتابعة باستخدام فيسبوك";
  static const String finished = "منتهي";
  static const String forget_password = "نسيت كلمة المرور؟";
  static const String free = "مجاني";
  static const String free_bundle_instructions =
      'الرزمة المجانيّة:\nإملأ بياناتك في التطبيق من أجل الحصول على الاشتراك المجاني، وستحصل على الامتيازات التالية:\n1. إمكانية البحث في قاعدة البيانات عن مواصفات الشريك الذي يناسبك.\n2. إمكانية الحصول على اقتراحات يقدمها التطبيق وقد تناسبك وتجيب على طلبك.\n3. يمكن للمرشحين معرفة عدد المعجبين بالملف الشخصي.';
  static const String enterPayCard = "  أدخل رقم بطاقة ائتمان ";
  static const String enterValidPayCard = "   أدخل رقم بطاقة ائتمان صالح    ";
  static const String payementInstructions =
      "  موافقتك على الحصول على وصول فوري إلى اشتراكك، وأنه إذا لم تلغي قبل انتهاء الاشتراك في 26 مارس 2023، سيتم خصم رسوم الاشتراك تلقائيًا شهريًا حتى تقوم بالإلغاء. لن تكون مؤهلاً لاسترداد أموال عند الإلغاء.";

  static const String get_best = "إحصل على الأفضل";
  static const String golden_bundle = "الباقة الذهبية 400 شيكل";
  static const String golden_bundle_button = "  ابتداء من 400 شيقل";
  static const String google_sign_in = "المتابعة باستخدام جوجل";
  static const String gopaymentbutton = "انقر هنا لتنتقل الى الرزمة الذهبية";

  static const String have_account = "هل لديك حساب؟";
  static const String have_no_account = "ليس لديك حساب؟";
  static const String heDivorced = "منفصل";
  static const String hello = "مرحبا";
  static const String id = "الرقم التعريفي:";
  static const String image = "صورة";
  static const String impression = "انطباعك";
  static const String increase_watchers =
      "الحقيقة المثبتة تؤكد أن نشر صورك الشخصية الحقيقية   تزيد من عدد المشاهدين لملفك الشخصي، وتجعله اكثر جاذبية.";

  static const String isDialogShown = 'isDialogShown';
  static const String isFirst = 'isFirst';

  ///------------------- text cached -----------------------------

  static const String language = 'lang';
  static const String hasSetup = 'hasSetup';
  static const String hasRequired = 'hasRequired';
  static const String lastChat = "  19 يناير 2023 الساعة 4:14 مساءً";
  static const String likes = "الإعجابات";
  static const String login = "تسجيل الدخول";

  ///------------------- text messages -----------------------------
  static const String login_success = "Login Successfully";

  static const String login_to_reach_account =
      "سجل الدخول ليمكنك الوصول الى حسابك";

  ///------------------- text translated -----------------------------

  static const String onboarding =
      'لقد أنشأنا لجمع العزاب المذهلين الذين يريدون العثور على الحب والضحك والسعادة الأبدية!';

  static const String or = "او";
  static const String other = "اخرى";
  static const String others = "آخر";
  static const String package = "الرزمة";
  static const String partner = "شريكك";
  static const String password = "كلمة المرور";
  static const String password_again = "أدخل كلمة المرور مرة أخرى";
  static const String payment = "الدفع";
  static const String person_name = "الإسم الشخصي";
  static const String phone_no = "رقم الهاتف";
  static const String plz_check_your_mail =
      "من فضلك، قم بفحص بريدك الإلكتروني وانقر على الرابط المقدم للتحقق من عنوانك.";

  static const String ranged_age = "الفئة العمرية";
  static const String age = "عمر";

  static const String re_enter_pass = "إعادة تعيين كلمة المرور";
  static const String regigestersuccessfully = "تم انشاء الحساب بنجاح";
  static const String report = "الإبلاغ عن مشكلة";
  static const String report_user = "التقرير عن المستخدم";
  static const String resend_email = "إعادة إرسال البريد الإلكتروني للتحقق.";
  static const String review = "اترك تقييم للخدمة";
  static const String save = "حفظ";
  static const String search_for = "أبحث عن";
  static const String select_partner = "قم بتحديد مواصفات شريكك المناسب.";
  static const String send = "إرسال";
  static const String send_impression = "اترك رأيك أو رغبتك";
  static const String send_link = "إرسال الرابط";
  static const String setting = "إعدادات";
  static const String sheDivorced = "منفصلة";
  static const String single = "أعزب/ عزباء";
  static const String skip = "تجاوز";
  static const String some_information_about = "بعض المعلومات عنك";
  static const String startChat = "لقد تطابقت مع المستخدم يوم الاثنين 12";
  static const String the_login = "التسجيل";
  static const String token = 'token';
  static const String undersrtand = "فهمتها";
  static const String user_name = "اسم المستخدم";
  static const String validation_password =
      "يجب ان تحتوي كلمة المرور على تفاصيل على حرف كبير,  رقم  رمز واحد على الأقل.";

  static const String we_send_msg_to_you =
      "تمّ إرسال رسالة الى بريدك الالكتروني الآتي:test@gmail.com";

  static const String welcome = "مرحبا بك";
  static const String welcome_back = "مرحبًا بعودتك";
  static const String who_i =
      "من أنا؟ ( عرف عن نفسك بكلمات قليلة، مثل: مهنتك، ثقافتك،هواياتك، طموحاتك ومعلومات اخرى تراها مهمة للتعارف).";

  static const String wholikesyou =
      "هل تريد ان تعرف من أعجب بك؟ انتقل الى الرزمة الذهبية واشترك الآن.";

  static const String why_photo = "لماذا نريد صورة";
  static const String widower = "أرمل/ أرملة";
  static const String write_about_yourself = "اكتب بضع كلمات عن نفسك وهواياتك";
  static const String youAddedFeedbackToThApplication =
      'لقد قمت بإضافة تعليقات إلى التطبيق';

  static const String aboutAddedSuccessfully = 'تمت الإضافة بنجاح';

  static const String whereFrom = "  من أين أنت";
  static const String city = "  مدينة ";
  static const String min_age = "اقل عمر";
  static const String max_age = "اقصي عمر";

  static const String area = "  منطقة  ";
  static const String height = "طول";
  static const String weight = "وزن";
  static const String isSmoking = "هل تدخن";
  static const String yes = "نعم";
  static const String no = "لا";
  static const String error = 'خطأ لقد حدث';
  static const String logout = "تسجيل خروج";
  static const String mainly = "أساسي";
  static const String marital_status = "الحالة الاجتماعية";
  static const String married = "متزوج";
  static const String mayBeLater = "ربما في وقت لاحق";
  static const String me = "أنا";
  static const String msgs = "رسائل";
  static const String my_name = "اسمي";
  static const String my_personal_data = "مواصفاتي الشخصية";
  static const String required_data = "المواصفات المطلوبه";

  static const String new_code = "اطلب رمزًا جديدًا في الساعة 00:30";
  static const String new_couples = "ملائمات جديدة";
  static const String new_pass = "كلمة مرور جديدة";
  static const String next = "التالي";
  static const String nointernet = "Check Your Internet Connection";
  static const String not_mainly = "معيار";
  static const String notification = "إشعارات";
  static const String appReport = "الابلاغ عن مشكلة";
  static const String payementPossibility = " امكانيات الدفع ";
  static const String bankTransfer = " التحويل المصرفي";
  static const String payPall = " باي بال  ";
  static const String changeCountry = "  تغيير الدولة  ";

  static const String payementDetails = " بيانات الدفع    ";

  static const String cardNo = "    رقم البطاقة  ";

  static const String expiryDate = "   تاريخ الانتهاء  ";
  static const String payementPass = "  رمز الحماية  ";
  static const String idNo = " رقم الهوية  ";
  static const String payNow = " ادفع الآن   ";
  static const String checkEmail = "  تم إرسال البريد الإلكتروني   ";
  static const String enterPassword = " ادخل كلمة المرور ";
  static const String accountDeleted = "  Account Deleted Successfully  ";
  static final String DEVICEID = "DEVICEID";

}
