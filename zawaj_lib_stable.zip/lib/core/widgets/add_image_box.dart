import 'dart:io';

import 'package:flutter/material.dart';

import '../constants/dimensions.dart';
class AddImageBox extends StatelessWidget {
  const AddImageBox(this.height,this.width,this.path,this.onRemove,this.onAdd,{
    super.key,
  });

  final double height,width;

  final String? path;
  final onRemove;
  final onAdd;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onAdd,
      child: Container(
          height: height,
          width: width,
          decoration: BoxDecoration(
            color: const Color(0xffF1F4F9),
            borderRadius: BorderRadius.circular(Dimensions.buttonRadius),

          ),
          child: path==null?const Center(child: Icon(Icons.add_circle_outline,color:Color(0xffB9B9B9) ,)):
          Stack(
            alignment: Alignment.bottomRight,
            children: [
              ClipRRect(
                  borderRadius:BorderRadius.circular(Dimensions.buttonRadius) ,
                  child: Image.file(File(path!),fit: BoxFit.fill,height: height,width: width,)),
              Padding(
                padding: const EdgeInsets.all(20),
                child: InkWell(
                    onTap: onRemove,
                    child: const Center(child: Icon(Icons.highlight_remove,color:Color(0xffB9B9B9) ,))),
              )
            ],
          )

      ),
    );
  }
}