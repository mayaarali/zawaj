import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:popover/popover.dart';
import 'package:zawaj/core/constants/color_manager.dart';
import 'package:zawaj/core/constants/image_manager.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/widgets/custom_text.dart';
import 'package:zawaj/features/profile/presentation/pages/profile_page.dart';

class CustomAppBar extends StatefulWidget {
  const CustomAppBar(
      {super.key,
      this.isBack = true,
      this.title,
      this.isLogoTitle = false,
      this.leading,
      this.isHeartTitle = false,
      this.isMenuIcon = false,
      this.isSettingIcon = false,
      this.isShowOthers = false});
  final bool isBack;
  final bool isLogoTitle;
  final bool isHeartTitle;
  final bool isMenuIcon;
  final bool isSettingIcon;
  final String? title;
  final Widget? leading;
  final bool isShowOthers;

  @override
  State<CustomAppBar> createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  @override
  Widget build(BuildContext context) {
    Widget titleWidget;

    if (widget.isLogoTitle) {
      titleWidget = Image.asset(ImageManager.small_logo);
    } else if (widget.isHeartTitle) {
      titleWidget = SvgPicture.asset(ImageManager.heartLogo);
    } else {
      titleWidget = CustomText(
        text: widget.title,
        fontWeight: FontWeight.w400,
        fontSize: 25,
      );
    }

    Widget actionWidget;
    if (widget.isBack) {
      actionWidget = const ActionApp();
    } else if (widget.isMenuIcon) {
      actionWidget = const MenuButton();
    } else {
      actionWidget = const SizedBox();
    }
    /*
    Widget leadingWidget;
    if (widget.isSettingIcon) {
      leadingWidget = const SettingIcon();
    } else {
      leadingWidget = const SizedBox();
    }
*/
    return AppBar(
      automaticallyImplyLeading: false,
      surfaceTintColor: Colors.transparent,
      backgroundColor: Colors.white,
      elevation: 0,
      centerTitle: true,
      title: titleWidget,
      actions: [actionWidget],
      leading: widget.leading,
      //leadingWidget,
    );
  }
}

class ActionApp extends StatelessWidget {
  const ActionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          MagicRouter.goBack();
        },
        child: const Icon(
          Icons.arrow_forward,
          color: ColorManager.hintTextColor,
        ));
  }
}

class MenuButton extends StatelessWidget {
  const MenuButton({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: () {
          showPopover(
              context: context,
              bodyBuilder: (context) => const OtherEditsPopUp(),
              backgroundColor: Colors.transparent,
              radius: 25,
              width: 250);
        },
        child: SvgPicture.asset(ImageManager.menuIcon));
  }
}

class SettingIcon extends StatelessWidget {
  const SettingIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: SvgPicture.asset(
        ImageManager.settingIcon,
        fit: BoxFit.scaleDown,
      ),
    );
  }
}
