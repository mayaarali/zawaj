import 'package:easy_localization/easy_localization.dart';
import 'package:zawaj/core/constants/strings.dart';
import 'package:zawaj/features/authentication/presentation/pages/reset_password/reset_password.dart';

class Validator {
  static String? validateName(value) {
    if (value.isEmpty) {
      return ('Enter Name').tr();
    } else {
      return null;
    }
  }

  static String? validatePhone(value) {
    String pattern = r'(^[0-9]+$)';
    RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return 'Enter Phone';
    } else if (!regExp.hasMatch(value)) {
      return 'Phone Must be digits';
    } else {
      return null;
    }
  }

  static String? validateEmail(value) {
    // String pattern=
    //   r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    //RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return ('Enter Email').tr();
    } else if (!value.contains('@') && !value.contains('.com')) {
      return 'Invalid Email'.tr();
    } else {
      return null;
    }
  }

  static String? validatePassword(value) {
    if (value.isEmpty) {
      return 'Enter Password'.tr();
    } else if (value.length < 8) {
      return 'Password must be more than 8'.tr();
    } else {
      return null;
    }
  }

  static String? validateEmpty(value) {
    if (value.isEmpty) {
      return "It Can't be empty".tr();
    } else {
      return null;
    }
  }

  static String? validateConfirmPass(pass, confirm) {
    if (confirm.isEmpty) {
      return "It Can't be empty".tr();
    } else if (pass != confirm) {
      return "Wrong Password".tr();
    } else {
      return null;
    }
  }

  static String? validatePayementCard(value) {
    if (value.isEmpty) {
      return Strings.enterPayCard.tr();
    } else if (value.length < 16 || value.length > 16) {
      return Strings.enterValidPayCard.tr();
    } else {
      return null;
    }
  }

  static String? expiryCardDate(value) {
    if (value.isEmpty) {
      return "It Can't be empty".tr();
    } else if (value < DateTime.now().toString()) {
      return Strings.enterValidPayCard.tr();
    } else {
      return null;
    }
  }
}
