import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:zawaj/core/constants/color_manager.dart';

extension SnackBarEextension on BuildContext {
  void getSnackBar({required String snackText, bool isError = false}) =>
      ScaffoldMessenger.of(this).showSnackBar(SnackBar(
        backgroundColor: isError
            ? ColorManager.primaryColor
            : ColorManager.secondaryPinkColor,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(10),
        content: Text(
          snackText.tr(),
          style: TextStyle(
              color: isError
                  ? Colors.white
                  : ColorManager.primaryColor // Set the desired text color here
              ),
        ),
        duration: const Duration(seconds: 3),
      ));
}
