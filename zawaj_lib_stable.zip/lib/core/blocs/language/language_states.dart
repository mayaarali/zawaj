abstract class LanguageState{
}

class SelectLanguage extends LanguageState{}
class InitLanguageState extends LanguageState{}


