import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:zawaj/core/router/routes.dart';
import 'package:zawaj/core/theme/theme.dart';
import 'package:zawaj/features/authentication/presentation/pages/new_password/reenter_password.dart';
import 'package:zawaj/features/splash/view.dart';
import 'core/blocs/connectivity/bloc.dart';
import 'core/blocs/connectivity/events.dart';
import 'core/blocs/language/language_cubit.dart';
import 'core/blocs/language/language_states.dart';
import 'core/helper/app_providers.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        ...AppProviders.get(context),
        BlocProvider<InternetBloc>(
          create: (context) => InternetBloc(connectivity: Connectivity())
            ..add(ListenConnectivity()),
        ),
      ],
      child: BlocConsumer<LanguageCubit, LanguageState>(
        listener: (context, state) {},
        builder: (context, state) => MaterialApp(
            localizationsDelegates: context.localizationDelegates,
            supportedLocales: context.supportedLocales,
            locale: context.locale,
            navigatorKey: navigatorKey,
            showSemanticsDebugger: false,
            theme: themeData,
            debugShowCheckedModeBanner: false,
            home:
                const SplashView()), // This should never be reached, but is here to satisfy the builder function's requirement for a return value.
        //home: ReEnterPasswordPage()),
      ),
    );
  }
}
