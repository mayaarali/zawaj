import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:zawaj/app.dart';
import 'package:zawaj/core/constants/strings.dart';

import 'core/helper/bloc_observer.dart';
import 'core/helper/cache_helper.dart';
import 'core/helper/dio_helper.dart';
import 'injection_controller.dart' as di;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  FirebaseAuth.instance.authStateChanges().listen((User? user) {
    if (user == null) {
      print(
          '================================================>User is currently signed out!');
    } else {
      print(
          '================================================>User is signed in!');
    }
  });

  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  await CacheHelper.init();
  await di.init();
  await DioHelper.init();

  OneSignal.Debug.setLogLevel(OSLogLevel.verbose);

  OneSignal.initialize("30b87e9d-8b0d-4e52-8764-850cb0f0391f");
  print('oneeeeeeeeesignaal');
// The promptForPushNotificationsWithUserResponse function will show the iOS or Android push notification prompt. We recommend removing the following code and instead using an In-App Message to prompt for notification permission
  OneSignal.Notifications.requestPermission(true);

  String? id = await OneSignal.User.getOnesignalId();
  CacheHelper.setData(key: Strings.DEVICEID, value: id);
  print(id);
  OneSignal.User.pushSubscription.addObserver((state) {
    print("ussssserId");
    print(OneSignal.User.pushSubscription.optedIn);
    print(OneSignal.User.pushSubscription.id);
    print(OneSignal.User.pushSubscription.token);
    print(state.current.jsonRepresentation());
    CacheHelper.setData(
        key: Strings.DEVICEID, value: OneSignal.User.pushSubscription.id);
  });

  // Add this line to lock the orientation to portrait mode only
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  //await SignalR.connectAndStart();
  //await SignalRService.connectAndStart();
  Bloc.observer = SimpleBlocObserver();
  EasyLocalization.logger.enableBuildModes = [];
  runApp(EasyLocalization(
      supportedLocales: const [Locale('ar'), Locale('en')],
      path: 'assets/languages', // <-- change the path of the translation files
      fallbackLocale: const Locale('ar', ''),
      startLocale: const Locale('ar', ''),
      child: const MyApp()));
}
